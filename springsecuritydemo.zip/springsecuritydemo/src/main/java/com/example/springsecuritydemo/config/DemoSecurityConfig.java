package com.example.springsecuritydemo.config;

import com.example.springsecuritydemo.service.UserServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

import java.io.PrintWriter;

/**
 * Note that WebSecurityConfigurerAdapter is deprecated,
 * Using SecurityFilterChain and WebSecurityCustomizer instead.
 **/
@EnableWebSecurity
@Configuration
public class DemoSecurityConfig {
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        //antMatchers按照先后顺序来匹配，一旦匹配成功就不继续匹配了。
        //所以范围小的放在前面，范围大的放在后面
        //url and role are added to a FilterSecurityInterceptor的 FilterInvocationSecurityMetadataSource属性中
        http.authorizeRequests()
//                .antMatchers("/admin/**").hasRole("ADMIN")
//                .antMatchers("/**").hasRole("USER")
                .anyRequest().authenticated()
                .and()
                .formLogin().loginProcessingUrl("/login")
                .failureUrl("/login?error")
                .permitAll()
                .and()
                .csrf()
                .disable();
        DefaultSecurityFilterChain build = http.build();
        return build;
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http)
            throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                .userDetailsService(userDetailsService())
                .passwordEncoder(bCryptPasswordEncoder())
                .and()
                .build();
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return new UserServiceImpl();
    }
//    @Bean
//    public WebSecurityCustomizer webSecurityCustomizer() {
//        return (web) -> web.ignoring().antMatchers("/resources/**");
//    }

//    @Bean
//    public AccessDeniedHandler accessDeniedHandler() {
//        return ((req, resp, ex)->{
//            resp.setContentType("application/json;charset=utf-8");
//            PrintWriter out = resp.getWriter();
//            out.write("No permission");
//            out.flush();
//            out.close();
//        });
//    }
}
