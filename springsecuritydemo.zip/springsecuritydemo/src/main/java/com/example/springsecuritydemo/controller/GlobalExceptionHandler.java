package com.example.springsecuritydemo.controller;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:00 2023/3/24
 * @Modified by lenovo
 **/
@ControllerAdvice
public class GlobalExceptionHandler {
    @ResponseBody
    public String handleNotFoundException(AccessDeniedException ex){
        return "no permission";
    }
}
