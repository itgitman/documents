package com.example.springsecuritydemo.controller;

import com.example.springsecuritydemo.dto.UserDto;
import com.example.springsecuritydemo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:50 2023/3/23
 * @Modified by lenovo
 **/
@RestController
@RequestMapping("/admin")
public class UserController {
    @Autowired
    private UserService userService;
    @GetMapping("/users/{id}")
    public UserDto findById(@PathVariable("id") Long id) {
        return userService.findById(id);
    }
}
