package com.example.springsecuritydemo.service;

import com.example.springsecuritydemo.dto.PermissionDto;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:39 2023/3/23
 * @Modified by lenovo
 **/
public interface PermissionService {
    List<PermissionDto> findByUserId(Long userId);
    List<PermissionDto> findAll();
//    void createPermission(Permission permission);
//    void updatePermission(Permission permission);
//    void deleteById(Long id);
}
