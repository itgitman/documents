package com.example.springsecuritydemo;

import com.example.springsecuritydemo.config.SimpleConfig;
import com.example.springsecuritydemo.model.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.util.Assert;

import java.util.stream.Stream;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 17:37 2023/3/28
 * @Modified by lenovo
 **/
public class AppCtxClient {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext applicationContext
                = new AnnotationConfigApplicationContext(SimpleConfig.class);
        Stream.of(applicationContext.getBeanDefinitionNames()).forEach(System.out::println);
        User user = applicationContext.getBean("user", User.class);
        User user1 = applicationContext.getBean("user", User.class);
        System.out.println(user == user1);
        applicationContext.close();

    }
}
