package com.example.springsecuritydemo.dao;

import com.example.springsecuritydemo.model.Permission;
import com.example.springsecuritydemo.model.User;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:39 2023/3/23
 * @Modified by lenovo
 **/
public interface PermissionDao {
    List<Permission> findByUserId(Long userId);
    List<Permission> findAll();
//    void createPermission(Permission permission);
//    void updatePermission(Permission permission);
//    void deleteById(Long id);
}
