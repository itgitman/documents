package com.example.springsecuritydemo.service;

import com.example.springsecuritydemo.dto.UserDto;
import com.example.springsecuritydemo.model.User;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:51 2023/3/23
 * @Modified by lenovo
 **/
public interface UserService {
    UserDto findById(Long id);
    UserDto findByUsername(String username);
}
