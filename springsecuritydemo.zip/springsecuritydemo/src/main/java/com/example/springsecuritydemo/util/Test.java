package com.example.springsecuritydemo.util;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 17:27 2023/3/28
 * @Modified by lenovo
 **/
public class Test {
    public static void main(String[] args) {
        Thread thread = new Thread(() -> System.out.println("Hi, world"));
        thread.start();

        new Thread(()->System.out.println("hello"));
    }
}
