package com.example.springsecuritydemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 5:14 2023/3/24
 * @Modified by lenovo
 **/
@RestController
public class HelloController {
    @GetMapping("/hello")
    public String sayHello() {
        return "hello, world";
    }
}
