package com.example.springsecuritydemo.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:33 2023/3/23
 * @Modified by lenovo
 **/
@Data
@NoArgsConstructor
public class User {
    private Long id;
    private String username;
    private String password;
    private List<Role> roles;
}
