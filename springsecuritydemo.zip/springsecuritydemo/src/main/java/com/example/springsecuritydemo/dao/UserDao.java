package com.example.springsecuritydemo.dao;

import com.example.springsecuritydemo.model.User;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:39 2023/3/23
 * @Modified by lenovo
 **/
public interface UserDao {
    User findById(Long id);
    User findByUsername(String username);
    List<User> findAll();
}
