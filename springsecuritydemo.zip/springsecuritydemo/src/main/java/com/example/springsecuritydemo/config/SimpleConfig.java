package com.example.springsecuritydemo.config;

import com.example.springsecuritydemo.model.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 17:43 2023/3/28
 * @Modified by lenovo
 **/
@Configuration
public class SimpleConfig {
    @Bean
    @Scope("prototype")
    public User user() {
        return new User();
    }
}
