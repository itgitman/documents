package com.example.springsecuritydemo.service;

import com.example.springsecuritydemo.dao.PermissionDao;
import com.example.springsecuritydemo.dto.PermissionDto;
import com.example.springsecuritydemo.model.Permission;
import com.example.springsecuritydemo.util.ModelConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:39 2023/3/23
 * @Modified by lenovo
 **/
@Service
public class PermissionServiceImpl implements PermissionService {
    @Autowired
    private PermissionDao permissionDao;
    public List<PermissionDto> findByUserId(Long userId) {
        List<Permission> permissions = permissionDao.findByUserId(userId);
        if(!CollectionUtils.isEmpty(permissions)) {
            return ModelConverter.convertToList(permissions, PermissionDto.class);
        }
        return null;
    }

    public List<PermissionDto> findAll() {
        List<Permission> permissions = permissionDao.findAll();
        return ModelConverter.convertToList(permissions, PermissionDto.class);
    }

//    void createPermission(Permission permission);
//    void updatePermission(Permission permission);
//    void deleteById(Long id);
}
