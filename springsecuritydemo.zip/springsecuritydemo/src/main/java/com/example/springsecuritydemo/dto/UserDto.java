package com.example.springsecuritydemo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:19 2023/3/23
 * @Modified by lenovo
 **/
@Data
@NoArgsConstructor
public class UserDto {
    private Long id;
    private String username;
    private String password;
}
