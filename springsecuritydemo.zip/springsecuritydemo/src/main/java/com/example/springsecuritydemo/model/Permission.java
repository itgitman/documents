package com.example.springsecuritydemo.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:54 2023/3/23
 * @Modified by lenovo
 **/
@Data
@NoArgsConstructor
public class Permission {
    private Long id;
    private String name;
    private String description;
    private String url;
    private Long pid; //父权限
}
