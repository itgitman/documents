package com.example.springsecuritydemo.controller;

import com.example.springsecuritydemo.dto.PermissionDto;
import com.example.springsecuritydemo.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:50 2023/3/23
 * @Modified by lenovo
 **/
@RestController
@RequestMapping("/admin")
public class PermissionController {
    @Autowired
    private PermissionService permissionService;
    @GetMapping("/permissions")
    public List<PermissionDto> findById(@RequestParam(value = "userId", required = true) Long userId) {
        return permissionService.findByUserId(userId);
    }
}
