package com.example.springsecuritydemo.util;

import com.example.springsecuritydemo.dto.UserDto;
import com.example.springsecuritydemo.model.User;
import org.springframework.beans.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:51 2023/3/23
 * @Modified by lenovo
 **/
public class ModelConverter {
    public static <T, R> R convert(T source, Class<R> clazz) {
        R result = null;
        try {
            result = clazz.getDeclaredConstructor().newInstance();
            BeanUtils.copyProperties(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static <T, R> List<R> convertList(List<T> sources, Class<R> clazz) {
        List<R> list = new ArrayList<>();
        for (T source : sources) {
            list.add(convert(source, clazz));
        }
        return list;
    }

    public static void main(String[] args) {

        ModelConverter.convert(new User(), UserDto.class);
    }
}
