package com.example.springsecuritydemo.service;

import com.example.springsecuritydemo.dao.PermissionDao;
import com.example.springsecuritydemo.dao.UserDao;
import com.example.springsecuritydemo.dto.UserDto;
import com.example.springsecuritydemo.model.Permission;
import com.example.springsecuritydemo.model.User;
import com.example.springsecuritydemo.util.ModelConverter;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:52 2023/3/23
 * @Modified by lenovo
 **/
@Service
@Transactional
public class UserServiceImpl implements UserService, UserDetailsService {
    @Autowired
    private UserDao userDao;
    @Autowired
    private PermissionDao permissionDao;
    @Override
    public UserDto findById(Long id) {
        User user = userDao.findById(id);
//        UserDto userDto = new UserDto();
//        BeanUtils.copyProperties(user, userDto);
        return ModelConverter.convert(user, UserDto.class);
    }
    public UserDto findByUsername(String username) {
        User user = userDao.findByUsername(username);
//        UserDto userDto = new UserDto();
//        BeanUtils.copyProperties(user, userDto);
        return ModelConverter.convert(user, UserDto.class);
    }

    @Override
    public UserDetails loadUserByUsername(String username) {
        User user = userDao.findByUsername(username);
        //无论用户名或密码不正确，都必须抛出BadCredentialsException而不是UsernameNotFoundException
        if(ObjectUtils.isEmpty(user))
            throw new BadCredentialsException("username is not found");
        List<Permission> permissions = permissionDao.findByUserId(user.getId());
        List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
        if(!CollectionUtils.isEmpty(permissions)) {
            grantedAuthorities = permissions.stream()
                    .map(e->new SimpleGrantedAuthority(e.getName()))
                    .collect(Collectors.toList());

        }
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), grantedAuthorities);
    }
}
