package com.example.springsecuritydemo.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:54 2023/3/23
 * @Modified by lenovo
 **/
@Data
@NoArgsConstructor
public class Role {
    private Long id;
    private String name;
    private List<Permission> permissions;
}
