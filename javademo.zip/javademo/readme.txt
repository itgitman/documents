1. Inner class
2. Generic
3. Lambda
4. Stream
5. Thread
高并发核心编程笔记