package com.example.java8;

import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:54 2023/4/18
 * @Modified by lenovo
 **/
public class MockDemo {
    public static void main(String[] args) {
        List<String> mockedList = Mockito.mock(ArrayList.class);
//打印mock对象的类名，看看mock对象为何物
        System.out.println("mock List==========="+mockedList.getClass().getName());
//操作mock对象
        mockedList.add("one");
        System.out.println("0 agr:"+mockedList.get(0));
        System.out.println("10 agr:"+mockedList.get(10));


//生成一个spy对象
        List<String> spyList = Mockito.spy(ArrayList.class);
//打印mock对象的类名，看看spy对象为何物
        System.out.println("spy List============"+spyList.getClass().getName());
//操作mock对象
        spyList.add("one");
        System.out.println("0 agr:"+spyList.get(0));
        System.out.println("10 agr:"+spyList.get(10));
    }
}

