package com.example.java8.optional;

import java.util.Optional;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 12:03 2022/11/11
 * @Modified by lenovo
 **/
public class Person {
    private Optional<Car> car;
    public Optional<Car> getCar() {
        return car;
    }
}
