package com.example.java8;

import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:13 2022/10/26
 * @Modified by lenovo
 **/
public class LambdaDemo {
    public static void main(String[] args) {
        // lambda expression is interface type not class type.
        Runnable newThread = () -> {System.out.println("Lambda Runnable");
            try {
                int i = 1/0;
            } catch(Exception e) {
                e.printStackTrace();
            }
            throw new IllegalArgumentException("hello");};
        new Thread(newThread).start();
        // parameter type is not primitive type.
        Function<Integer, Integer> func1 = x -> x + 5;
        System.out.println(func1.apply(10));
        IntFunction<Integer> intFunc = x -> x * x;
        System.out.println(intFunc.apply(10));
        //方法引用
        Supplier<String> consumer = String::new;
        String b = consumer.get();
        Function<String, String> function1 = String::new;
        String str = function1.apply("hello, world");
        System.out.println(str);
    }

    public void methodA() {
//        Runnable newThread = () -> {System.out.println("Lambda Runnable");
//            throw new IllegalArgumentException("hello");};
//        throw new IllegalAccessException();
    }

    public void methodB() {
        methodA();
    }
}
