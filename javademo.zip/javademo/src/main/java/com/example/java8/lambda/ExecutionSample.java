package com.example.java8.lambda;

import java.time.LocalDate;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 12:41 2023/4/15
 * @Modified by lenovo
 **/
public class ExecutionSample {
    public static boolean compute(String str) {
        System.out.println("executing ==> " + str);
        return str.contains("a");
    }

    public static String eagerMatch(boolean b1, boolean b2) {
        return b1 && b2 ? "match" : "incompatible";
    }

    // functional interface is used for lazy execution; defer execution of some code.
    // Supplier 表示结果的提供者。
    public static String lazyMatch(Supplier<Boolean> s1, Supplier<Boolean> s2) {
        return s1.get() && s2.get() ? "match" : "incompatible";
    }

    public static void main(String[] args) {
        System.out.println(ExecutionSample.eagerMatch(compute("bb"), compute("aa")));

        System.out.println(ExecutionSample.lazyMatch(() -> compute("bb"), () -> compute("aa")));

        LocalDate day = null;
        //lazy execution
        LocalDate localDate = Objects.requireNonNullElseGet(day, ()->LocalDate.of(1970,1,1));
        System.out.println(localDate);
    }
}
