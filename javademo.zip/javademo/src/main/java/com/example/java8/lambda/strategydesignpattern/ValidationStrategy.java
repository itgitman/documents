package com.example.java8.lambda.strategydesignpattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:57 2023/4/15
 * @Modified by lenovo
 **/
public interface ValidationStrategy {
    boolean validate(String s);
}
