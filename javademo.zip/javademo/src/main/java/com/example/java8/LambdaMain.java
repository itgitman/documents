package com.example.java8;

import java.util.function.Consumer;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:11 2023/4/6
 * @Modified by lenovo
 **/
public class LambdaMain {
    public static void main(String[] args) {
        Operator op = (x, y) -> x + y;
        int result = op.operation(3, 4);
        System.out.println(result);

        Consumer<String> consumer = System.out::println;
        consumer.andThen(consumer).andThen(consumer);
        consumer.accept("ABC");

    }
}
