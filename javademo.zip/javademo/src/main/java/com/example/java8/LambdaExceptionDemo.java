package com.example.java8;

import java.io.IOException;
import java.util.Arrays;
import java.util.function.Consumer;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:53 2023/1/21
 * @Modified by lenovo
 **/
public class LambdaExceptionDemo {
    void doWrite(String msg) throws IOException {
        throw new IOException(msg + " not found");
        //do sth
    }
    void write() {
        Arrays.asList("aaa", "bbb").forEach(e-> {
            try {
                doWrite(e);
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    void write2() {
        Arrays.asList("aaa", "bbb").forEach(
                consumerWrapper(i -> doWrite(i), IOException.class)
        );
    }
    static <T, E extends Exception> Consumer<T> consumerWrapper
            (ThrowingConsumer<T, E> throwingConsumer, Class<E> exceptionClass) {
        return i -> {
            try {
                throwingConsumer.accept(i);
            } catch (Exception e) {
                try {
                    E cast = exceptionClass.cast(e);
                    System.err.println(cast.getMessage());
                } catch (Exception ex) {
                    throw new RuntimeException(e.getMessage());
                }
            }
        };
    }

    public static void main(String[] args) {
        new LambdaExceptionDemo().write2();
    }
}
