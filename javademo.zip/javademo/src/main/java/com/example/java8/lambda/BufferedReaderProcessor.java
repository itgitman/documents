package com.example.java8.lambda;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:35 2023/4/15
 * @Modified by lenovo
 **/
@FunctionalInterface
public interface BufferedReaderProcessor {
    String process(BufferedReader br) throws IOException;
}
