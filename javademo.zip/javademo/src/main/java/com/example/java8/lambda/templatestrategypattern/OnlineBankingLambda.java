package com.example.java8.lambda.templatestrategypattern;

import java.util.function.Consumer;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:06 2023/4/15
 * @Modified by lenovo
 **/
public class OnlineBankingLambda {
    public void processCustomer(String name, Consumer<String> makeCustomerHappy) {
        makeCustomerHappy.accept(name);
    }

    public static void main(String[] args) {
        OnlineBankingLambda onlineBankingLambda = new OnlineBankingLambda();
        onlineBankingLambda.processCustomer("Jack Lu", s -> System.out.println("Welcome " + s));
    }
}
