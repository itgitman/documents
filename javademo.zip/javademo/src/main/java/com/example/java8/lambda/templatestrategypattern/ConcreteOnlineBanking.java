package com.example.java8.lambda.templatestrategypattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:02 2023/4/15
 * @Modified by lenovo
 **/
public class ConcreteOnlineBanking extends OnlineBanking {
    @Override
    protected void makeCustomerHappy(String customerName) {
        System.out.println("Welcome " + customerName);
    }
}
