package com.example.java8.optional;

import com.sun.org.apache.xerces.internal.dom.PSVIAttrNSImpl;
import sun.misc.resources.Messages_sv;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 12:04 2022/11/11
 * @Modified by lenovo
 **/
public class Insurance {
    private String name;
    public String getName() {
        return name;
    }
}
