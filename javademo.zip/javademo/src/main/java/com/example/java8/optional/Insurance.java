package com.example.java8.optional;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 12:04 2022/11/11
 * @Modified by lenovo
 **/
public class Insurance {
    private String name;
    public String getName() {
        return name;
    }
}
