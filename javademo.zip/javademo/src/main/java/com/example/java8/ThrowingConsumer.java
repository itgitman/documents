package com.example.java8;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:33 2023/1/21
 * @Modified by lenovo
 **/
@FunctionalInterface
public interface ThrowingConsumer<T, E extends Exception> {
    void accept(T t) throws E;
}
