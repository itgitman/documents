package com.example.java8;

import javax.sound.midi.Soundbank;

import static java.util.stream.Collectors.*;
import static java.util.Comparator.*;

import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:13 2022/10/26
 * @Modified by lenovo
 **/
public class StreamDemo {
    static List<Employee> employees = Arrays.asList(
            new Employee("Peter", true, "DEV", 2000, Employee.Type.IC1),
            new Employee("Candy", false, "DEV", 5000, Employee.Type.IC2),

            new Employee("Wennie", false, "QA", 1000, Employee.Type.IC1),
            new Employee("Job", true, "QA", 4000, Employee.Type.IC3),
            new Employee("Kiki", false, "QA", 6000, Employee.Type.IC3),

            new Employee("Caris", true, "SALES", 3000, Employee.Type.IC1),
            new Employee("Harry", true, "SALES", 3000, Employee.Type.IC2),
            new Employee("Mandy", false, "SALES", 5500, Employee.Type.IC2));

    public static void main(String[] args) {
        long numOfEmployees = employees.stream().count();
        System.out.println("numOfEmployees=" + numOfEmployees);

        numOfEmployees = employees.stream().mapToInt(e -> 1).sum();
        System.out.println("numOfEmployees=" + numOfEmployees);

        long numOfQAs = employees.stream().filter(e -> e.getDepartment().equals("QA")).count();
        System.out.println("numOfQAs=" + numOfQAs);
        employees.stream().mapToInt(e -> e.getSalary()).average();

        Predicate<Employee> predicate = (Employee e) -> e.getDepartment().equals("QA"); //composed Predicate
        long numOfIC2QAs = employees.stream().filter(predicate.and(e -> e.getType().equals(Employee.Type.IC2))).count();
        System.out.println("numOfIC2QAs=" + numOfIC2QAs);

        BiPredicate<String, Integer> biPredicate = (s, n) -> s.equals("DEV") && n > 3000;
        List<Employee> list1 = employees.stream().filter(e -> biPredicate.test(e.getDepartment(), e.getSalary())).collect(toList());
        System.out.println("employees with salary>3000: " + list1);
        List<Employee> qas = employees.stream().filter(e -> e.getDepartment().equals("QA")).collect(toList());
        System.out.println("QAs=" + qas);

        List<Employee> empSortedBySalary = employees.stream().sorted(comparing(Employee::getSalary)).collect(toList());
        System.out.println("empSortedBySalary=" + empSortedBySalary);

        List<Employee> empSortedBySalaryAndReversedType = employees.stream().sorted(
                comparing(Employee::getSalary).thenComparing(Employee::getType).reversed()).collect(toList()); //composed comparator
        System.out.println("empSortedBySalaryAndReversedType=" + empSortedBySalaryAndReversedType);

        long maxSalary = employees.stream().mapToInt(Employee::getSalary).max().getAsInt();
        System.out.println("maxSalary=" + maxSalary);

        long maxSalary1 = employees.stream().map(Employee::getSalary).reduce(0, Integer::max);
        System.out.println("maxSalary=" + maxSalary1);

        Employee employeeInMaxSalary = employees.stream().reduce((e1, e2) -> e1.getSalary() > e2.getSalary() ? e1 : e2).get();
        System.out.println("employeeInMaxSalary=" + employeeInMaxSalary);

        Employee employeeInMaxSalary1 = employees.stream().collect(maxBy(comparing(Employee::getSalary))).get();
        System.out.println("employeeInMaxSalary=" + employeeInMaxSalary1);

        long totalSalary = employees.stream().collect(summingInt(Employee::getSalary));
        System.out.println("totalSalary=" + totalSalary);

        long totalSalary1 = employees.stream().collect(reducing(0, Employee::getSalary, Integer::sum));
        System.out.println("totalSalary=" + totalSalary1);

        long totalSalary2 = employees.stream().collect(mapping(Employee::getSalary, reducing(0, Integer::sum)));
        System.out.println("totalSalary=" + totalSalary2);

        long totalSalary3 = employees.stream().mapToInt(Employee::getSalary).sum();
        System.out.println("totalSalary=" + totalSalary3);

        long totalSalary4 = employees.stream().map(Employee::getSalary).reduce(0, Integer::sum);
        System.out.println("totalSalary=" + totalSalary4);

        long totalSalary5 = employees.stream().map(Employee::getSalary).reduce(0, (x1, x2) -> x1 + x2);
        System.out.println("totalSalary=" + totalSalary5);

        long totalSalary6 = employees.stream().reduce(0, (partial, e) -> partial + e.getSalary(), Integer::sum);
        System.out.println("totalSalary=" + totalSalary6);

        Map<String, List<Employee>> empGrpByDpt = employees.stream().collect(groupingBy(Employee::getDepartment));
        System.out.println("empGrpByDpt=" + empGrpByDpt);

        Map<String, Map<Employee.Type, List<Employee>>> empGrpByDpt2Typ = employees.stream().collect(groupingBy(Employee::getDepartment,
                groupingBy(Employee::getType)));
        System.out.println("empGrpByDpt2Typ=" + empGrpByDpt2Typ);

        Map<String, Employee> empInMaxSalaryGrpByDpt = employees.stream().collect(groupingBy(Employee::getDepartment,
                collectingAndThen(maxBy(comparing(Employee::getSalary)), Optional::get)));
        System.out.println("empInMaxSalaryGrpByDpt=" + empInMaxSalaryGrpByDpt);

        Map<String, Integer> maxSalaryOfEmpGrpByDpt = employees.stream().collect(groupingBy(Employee::getDepartment,
                mapping(Employee::getSalary, reducing(0, Integer::max))));
        System.out.println("maxSalaryOfEmpGrpByDpt=" + maxSalaryOfEmpGrpByDpt);

        Map<String, String> namesGrpByDpt = employees.stream().collect(groupingBy(Employee::getDepartment,
                mapping(Employee::getName, joining(", "))));
        System.out.println("namesGrpByDpt=" + namesGrpByDpt);

        Map<String, Long> numOfEmpGrpByDpt = employees.stream().collect(groupingBy(Employee::getDepartment,
                counting()));
        System.out.println("numOfEmpGrpByDpt=" + numOfEmpGrpByDpt);

        //Collector => groupingBy, partitioningBy, mapping, reducing, collectingAndThen, counting, joining, summingInt, maxBy, toList
        //findAny, findFirst, anyMatch, allMatch, noneMatch, flatMap, limit, distinct, skip
        Function<Employee, String> func = Employee::getName;
        Function<String, String> func1 = String::toUpperCase;
        List<String> upperCaseOfNames = employees.stream().map(func.andThen(func1)).collect(toList()); //composed Function
        System.out.println("upperCaseOfNames=" + upperCaseOfNames);
        //由函数创建流
        IntStream.rangeClosed(1, 100).sum();
        Stream<Double> doubleStream = Stream.generate(Math::random).limit(5);
        IntStream.iterate(0, n -> n + 2).limit(5).forEach(System.out::println);
        //由值创建流
        Stream<String> hello = Stream.of("Hello", "World");
        hello.forEach(System.out::println);
        //由数组创建流
        int[] numbers = {1, 2, 3, 4, 5};
        Arrays.stream(numbers).forEach(System.out::println);
        //由文件创建流
        //flatMap
        OptionalDouble average = employees.stream().mapToDouble(e -> e.getSalary()).average();
        System.out.println("Average salary: " + average.orElse(-1));
    }

    static class Employee {
        private final String name;
        private final String department;
        private final int salary;
        private final Type type;
        private final boolean isMale;

        enum Type {
            IC1, IC2, IC3, IC4
        }

        public Employee(String name, boolean isMale, String department, int salary, Type type) {
            this.name = name;
            this.isMale = isMale;
            this.department = department;
            this.salary = salary;
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public boolean isMale() {
            return isMale;
        }

        public String getDepartment() {
            return department;
        }

        public int getSalary() {
            return salary;
        }

        public Type getType() {
            return type;
        }

        public String toString() {
            return name + ":" + this.department + ":" + this.salary + ":" + this.type;
        }
    }
}
