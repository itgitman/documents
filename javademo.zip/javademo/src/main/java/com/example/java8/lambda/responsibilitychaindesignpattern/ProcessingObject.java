package com.example.java8.lambda.responsibilitychaindesignpattern;

import java.util.function.Function;
import java.util.function.UnaryOperator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:10 2023/4/15
 * @Modified by lenovo
 **/
public class ProcessingObject {
    public String process(String s, Function<String, String> pipeline) {
        return pipeline.apply(s);
    }
    public static void main(String[] args) {
        ProcessingObject processingObject = new ProcessingObject();
        UnaryOperator<String> headerProcessing =  s -> "From: " + s;
        UnaryOperator<String> spellCheckerProcessing = s -> s.replaceAll("labda", "lambda");
        //两个对象链接起来
        Function<String, String> pipeline = headerProcessing.andThen(spellCheckerProcessing);
        String result = processingObject.process("Aren't labdas", pipeline);
        System.out.println(result);
    }
}
