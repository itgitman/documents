package com.example.java8.lambda.observerdesignpattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:40 2023/4/15
 * @Modified by lenovo
 **/
public interface Observer {
    void notify(String tweet);
}
