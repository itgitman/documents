package com.example.java8;

import java.util.function.IntBinaryOperator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:27 2022/11/12
 * @Modified by lenovo
 **/
public class MathOperationUtil {
    public static int operation(int x, int y, IntBinaryOperator op) {
        return op.applyAsInt(x, y);
    }
    public static void main(String[] args) {
        int result = MathOperationUtil.operation(3, 5, (x, y) -> x * y);
    }
}
