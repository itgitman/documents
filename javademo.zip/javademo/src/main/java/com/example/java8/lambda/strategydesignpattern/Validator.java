package com.example.java8.lambda.strategydesignpattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:52 2023/4/15
 * @Modified by lenovo
 **/
public class Validator {
    private ValidationStrategy validationStrategy;
    public Validator(ValidationStrategy strategy) {
        this.validationStrategy = strategy;
    }

    public boolean execute(String s) {
        return validationStrategy.validate(s);
    }

    public static void main(String[] args) {
        Validator numericalValidator = new Validator(s -> s.matches("\\d+"));
        boolean b1 = numericalValidator.execute("12345A");
        System.out.println(b1);
        Validator lowerCaseValidator = new Validator(s -> s.matches("\\d+"));
        boolean b2 = lowerCaseValidator.execute("Sunny");
        System.out.println(b2);
    }
}
