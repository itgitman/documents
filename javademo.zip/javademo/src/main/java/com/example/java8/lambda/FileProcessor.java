package com.example.java8.lambda;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:37 2023/4/15
 * @Modified by lenovo
 **/
public class FileProcessor {
    public static String processFile(String path) throws IOException {
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            return br.readLine();
        }
    }
    //execute around mode - 环绕执行
    public static String processFile(String path, BufferedReaderProcessor ps) throws IOException {
        try(BufferedReader br = new BufferedReader(new FileReader(path))){
            return ps.process(br);
        }
    }

    public static void main(String[] args) {
        try {
            //使用函数式接口传递行为 - 行为参数化 Behavior parameterization
            String line = FileProcessor.processFile("test.txt", x -> x.readLine() + x.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
