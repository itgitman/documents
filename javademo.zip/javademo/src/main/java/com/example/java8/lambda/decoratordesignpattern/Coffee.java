package com.example.java8.lambda.decoratordesignpattern;

import java.util.function.Function;
import java.util.stream.Stream;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 18:00 2023/4/15
 * @Modified by lenovo
 **/
public class Coffee {
    private String name;
    private Stream<Function<String, String>> coffeeDecoratorStream;

    public Coffee(String name, Function<String, String>... cofferDecorators) {
        this.name = name;
        this.coffeeDecoratorStream = Stream.of(cofferDecorators);
    }

    public String getCoffee() {
        Function<String, String> composedDecorator =
                coffeeDecoratorStream.reduce(
                        (decorator, next) -> decorator.compose(next)).orElse(coffee -> coffee);
        return composedDecorator.apply(this.name);
    }

    public static void main(String[] args) {
        Coffee coffee = new Coffee("pure coffee", x -> x + " with sugar", x -> x + " with Mocha", x -> x + " with other");
        System.out.println(coffee.getCoffee());
    }
}
