package com.example.java8.lambda.decoratordesignpattern;

import java.awt.*;
import java.util.function.Function;
import java.util.stream.Stream;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 17:30 2023/4/15
 * @Modified by lenovo
 **/
public class Camera {
    private Color color;
    private Stream<Function<Color, Color>> filtersStream;

    public Camera(Color color, Function<Color, Color>... filters) {
        this.color = color;
        this.filtersStream = Stream.of(filters);
    }

    public Color getColor() {
        Function<Color, Color> composedFilter = filtersStream.reduce(
                (filter, next) -> filter.compose(next))
                .orElse(color -> color);

        return composedFilter.apply(this.color);
    }

    public static void main(String[] args) {
        Camera camera = new Camera(new Color(250, 0, 0), Color::brighter, Color::darker);
        Color color = camera.getColor();
        System.out.println(color);
    }
}
