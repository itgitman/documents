package com.example.java8.lambda.templatestrategypattern;

import java.util.function.Consumer;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:06 2023/4/15
 * @Modified by lenovo
 **/
public abstract class OnlineBanking {
    public void processCustomer(String customerName) {
        makeCustomerHappy(customerName);
    }
    protected abstract void makeCustomerHappy(String customerName);

    public static void main(String[] args) {

    }
}
