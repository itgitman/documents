package com.example.java8.lambda.factorydesignpattern;

import com.sun.tools.javac.Main;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:10 2023/4/15
 * @Modified by lenovo
 **/
public class ProductFactory {
    final static Map<String, Supplier<Product>> productMap = new HashMap<>();

    static {
        productMap.put("loan", Loan::new);
        productMap.put("bond", Bond::new);
        productMap.put("stock", Stock::new);
    }

    public Product createProduct(String name) {
        Supplier<Product> p = productMap.get(name);
        if (p != null) return p.get();
        throw new IllegalArgumentException("No such product " + name);
    }

    public static void main(String[] args) {
        ProductFactory productFactory = new ProductFactory();
        Product bond = productFactory.createProduct("bond");
    }
}


