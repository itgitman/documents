package com.example.java8.optional;

import javax.sound.midi.Soundbank;
import java.util.Optional;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 12:06 2022/11/11
 * @Modified by lenovo
 **/
public class OptionalMain {
    public String getCarInsuranceName(Person person) {
        return Optional.ofNullable(person)
                .flatMap(Person::getCar)
                .flatMap(Car::getInsurance)
                .map(Insurance::getName)
                .orElse("unknown");
    }

    public static void main(String[] args) {
        OptionalMain optionalMain = new OptionalMain();
        String result = optionalMain.getCarInsuranceName(null);
        System.out.println(result);
    }
}
