package com.example.java8.lambda.observerdesignpattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:41 2023/4/15
 * @Modified by lenovo
 **/
public interface Subject {
    void registerObserver(Observer o);
    void notifyObserver(String tweet);
}
