package com.example.java8.lambda.observerdesignpattern;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:09 2023/4/15
 * @Modified by lenovo
 **/
public class Feed implements Subject {
    private List<Observer> observers = new ArrayList<>();

    @Override
    public void registerObserver(Observer o) {
        this.observers.add(o);
    }

    @Override
    public void notifyObserver(String tweet) {
        observers.forEach(e -> e.notify(tweet));
    }

    public static void main(String[] args) {
        Feed feed = new Feed();
        feed.registerObserver( (String tweet) -> {
            if(tweet != null && tweet.contains("money")) {
                System.out.println("Breaking news in NY! " + tweet);
            }
        });
        feed.registerObserver((String tweet) -> {
            if(tweet != null && tweet.contains("queen")) {
                System.out.println("Another news in London: " + tweet);
            }
        });
        feed.notifyObserver("queen is dead");
    }
}
