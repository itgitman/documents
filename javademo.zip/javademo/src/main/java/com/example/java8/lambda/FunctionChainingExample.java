package com.example.java8.lambda;

import java.util.function.Function;
import java.util.logging.Logger;

/**
 * 函数链是函数式编程中的一种技术，它涉及将多个函数组合到单个管道或链中。
 * Function的 andThen, compose方法
 */
public class FunctionChainingExample {

    static Logger logger = Logger.getLogger(FunctionChainingExample.class.getName());

    private static Function<Integer, Integer> multiply = x -> x * 2;

    private static Function<Integer, Integer> add = x -> x + 2;

    private static Function<Integer, Integer> logOutput = x -> {
        logger.info("Data:" + x);
        return x + 10;
    };
    //柯里化
    private static Function<Integer, Function<Integer, Function<Integer, Integer>>>
            sumWithThreeParams = (a) -> (b) -> (c) -> a + b + c;

    private static Function<Integer, Function<Integer, Function<Integer, Function<Integer, Integer>>>> sumWithFourParams = (a) -> (b) -> (c) -> (d) -> a + b + c + d;

    public static Integer execute(Integer input) {
        Function<Integer, Integer> pipeline = multiply
                .andThen(add)
                .andThen(logOutput);
        return pipeline.apply(input);
    }

    public static void output() {
        System.out.println("method reference");
    }
    public static void main(String[] args) {
        System.out.println(execute(10));

        Function<Integer, Function<Integer, Integer>> partialSumWithTwoParams = sumWithThreeParams.apply(5);
        Function<Integer, Integer> partialSumWithOneParams = partialSumWithTwoParams.apply(10);
        int c = 15;
        int result = partialSumWithOneParams.apply(c);
        System.out.println(result); //30
        Runnable output = FunctionChainingExample::output;
    }
}