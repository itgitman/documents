什么时候需要在代码中引入函数式接口来提高代码的灵活性？
1. 有条件的延迟执行
2. 环绕执行

Java已有的函数式接口
Predicate
    BiPredicate
    DoublePredicate
    IntPredicate
    LongPredicate
Function 表示接受一个参数并产生结果的函数。
    DoubleFunction
    DoubleToIntFunction
    DoubleToLongFunction
    IntFunction
    IntToDoubleFunction
    IntToLongFunction
    LongFunction
    LongToDoubleFunction
    LongToIntFunction
    ToDoubleFunction
    ToIntFunction
    ToLongFunction
    BiFunction
    ToIntBiFunction
    ToDoubleBiFunction
    ToLongBiFunction
Consumer
    BiConsumer
    DoubleConsumer
    Consumer
    LongConsumer
    ObjDoubleConsumer
    ObjIntConsumer
    ObjLongConsumer
Supplier - represents a supplier of results. - 此接口最常见的用例之一是延迟某些代码的执行。One of the most frequent use cases of this interface is to defer the execution of some code.
    BooleanSupplier
    DoubleSupplier
    IntSupplier
    LongSupplier
BinaryOperator - extends BiFunction 表示对两个相同类型的操作数的操作，产生与操作数相同类型的结果。这是bifuncfunction的专门化，用于操作数和结果都是同一类型的情况。
    DoubleBinaryOperator
    IntBinaryOperator
    LongBinaryOperator
UnaryOperator - extends Function 表示对单个操作数的操作，该操作数产生与其操作数类型相同的结果。这是Function的专门化，用于操作数和结果类型相同的情况。
    DoubleUnaryOperator
    IntUnaryOperator
    LongUnaryOperator

Runnable
Callable
Comparator