package com.example.java8;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:03 2023/4/14
 * @Modified by lenovo
 **/
public class Student {
    private String name;
    private int age;

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean validate(Predicate<Student> predicate) {
        return predicate.test(this);
    }

    public void consumer(Consumer<Student> consumer) {
        consumer.accept(this);
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public static void main(String[] args) {
//        List<Student> students = List.of(new Student("Jack", 22),
//                new Student("Sam", 21),
//                new Student("Evan", 23),
//                new Student("Jackie", 21));
        Student s1 = new Student("Jerry", 25);
        boolean valid = s1.validate(e -> e.getName().matches("^[A-Z][A-Za-z]*") && e.getAge() > 18);
        System.out.println(valid);
        s1.consumer(e -> System.out.println(e.getAge()));

//        Comparator<Student> comparator = Comparator.comparing(Student::getAge).thenComparing(Student::getName);
//        students.stream().sorted(comparator).forEach(System.out::println);
//        BiPredicate<String, Integer> biPredicate = (n, a) -> n.startsWith("Jack") && a > 18;
//        List<Student> collect = students.stream().filter(e -> biPredicate.test(e.getName(), e.getAge())).collect(Collectors.toList());
//        collect.forEach(System.out::println);

        BiFunction<String, Integer, Student> func = Student::new;
        Student sunny = func.apply("Sunny", 20);

        Supplier<Student> supplier1 = Student::new;
        Student student = supplier1.get();

        Supplier<Student> supplier = () -> new Student("Sunny", 18);
        Student student1 = supplier.get();
    }
}
