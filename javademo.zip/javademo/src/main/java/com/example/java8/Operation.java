package com.example.java8;

import javax.sound.midi.Soundbank;
import java.util.function.BiFunction;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:27 2022/11/12
 * @Modified by lenovo
 **/
public class Operation {
    public static Integer exec(Integer x, Integer y, BiFunction<Integer, Integer, Integer> biFunction) {
        return biFunction.apply(x, y);
    }
    public static void main(String[] args) {
        Integer result = Operation.exec(3, 5, (x, y) -> x * y);
        System.out.println(result);
        Operation operation = new Operation();

        System.out.println(operation);
        System.out.println(Integer.toHexString(operation.hashCode()));

        Operation operation1 = new Operation();
        System.out.println(operation1);
        String str = new String("abc");
        //定义对象的类； 和对象的引用的类型
    }
}
