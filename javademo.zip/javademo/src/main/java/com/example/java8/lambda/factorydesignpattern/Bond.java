package com.example.java8.lambda.factorydesignpattern;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:13 2023/4/15
 * @Modified by lenovo
 **/
public class Bond extends Product {
}
