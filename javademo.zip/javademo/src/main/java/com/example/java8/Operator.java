package com.example.java8;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:11 2023/4/6
 * @Modified by lenovo
 **/
public interface Operator {
    int operation(int x, int y);
}
