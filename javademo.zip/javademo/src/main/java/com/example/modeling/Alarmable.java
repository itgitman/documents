package com.example.modeling;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:51 2023/2/21
 * @Modified by lenovo
 **/
public interface Alarmable {
    void alarm();
}
