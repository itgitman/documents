package com.example.modeling;

/**
 * a SafeDoor is a Door (Is-a relationship)
 * a SafeDoor has Alarm functionality, 安全门具体报警功能
 *
 * Another example:
 * an Integer is a Number, it has Comparable functionality
 **/
public class SafeDoor extends AbstractDoor implements Alarmable {
    @Override
    public void open() {
        //TODO
    }

    @Override
    public void close() {
        //TODO
    }

    @Override
    public void alarm() {
        //TODO
    }
}
