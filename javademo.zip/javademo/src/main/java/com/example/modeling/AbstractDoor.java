package com.example.modeling;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:50 2023/2/21
 * @Modified by lenovo
 **/
public abstract class AbstractDoor {
    public abstract void open();
    public abstract void close();
}
