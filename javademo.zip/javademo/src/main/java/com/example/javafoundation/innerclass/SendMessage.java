package com.example.javafoundation.innerclass;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 19:45 2023/5/22
 * @Modified by lenovo
 **/
public class SendMessage {
    public void send(String phoneNumber) {
        System.out.println("Sending message to " + phoneNumber);
    }
}
