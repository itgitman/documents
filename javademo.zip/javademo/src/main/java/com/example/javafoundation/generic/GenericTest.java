package com.example.javafoundation.generic;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 19:40 2023/5/22
 * @Modified by lenovo
 **/
public class GenericTest {

    //    private T[] codes = new T[] {};
    public String test(String str) {
        System.out.println("non-generic method");
        return str;
    }

    public <T> T test(T str) {
        System.out.println("generic method");
        return str;
    }

    public static void main(String[] args) {
        GenericTest genericTest = new GenericTest();
        genericTest.test("abc");
    }
}
