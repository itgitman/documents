package com.example.javafoundation.innerclass;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 19:44 2023/5/22
 * @Modified by lenovo
 **/
public class Call {
    public void call(String phoneNumber) {
        System.out.println("Calling " + phoneNumber);
    }
}
