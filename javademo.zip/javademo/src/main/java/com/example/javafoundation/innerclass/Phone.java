package com.example.javafoundation.innerclass;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 19:46 2023/5/22
 * @Modified by lenovo
 **/
public class Phone {
    private Call call = new MyCall();
    private SendMessage sendMessage = new MySendMessage();
    private class MyCall extends Call {

    }

    private class MySendMessage extends SendMessage {

    }

    public void call(String phoneNumber) {
        call.call(phoneNumber);
    }

    public void send(String phoneNUmber) {
        sendMessage.send(phoneNUmber);
    }
}
