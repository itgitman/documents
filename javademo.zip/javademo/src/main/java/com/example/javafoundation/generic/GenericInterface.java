package com.example.javafoundation.generic;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 19:40 2023/5/22
 * @Modified by lenovo
 **/
public interface GenericInterface {

    //    private T[] codes = new T[] {};
    public String test(String str);

    public <T> T test(T str);
}
