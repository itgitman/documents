package com.example.javafoundation;

import java.io.OutputStream;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:18 2023/5/2
 * @Modified by lenovo
 **/
public abstract class Demo {
    public static void main(String[] args) {
        //Returns a fixed-size list backed by the specified array
        List<String> strings = Arrays.asList("a", "b", "c");
        strings.replaceAll(s -> "d");
        strings.forEach(System.out::println);

        List<String> strList1 = new ArrayList<>();
        strList1.add("a1");
        strList1.add("b1");
        strList1.add("c1");
        List<String> list = Collections.unmodifiableList(strList1);
//        list.replaceAll(s -> "d1");

        List<String> strList2 = List.of("a1", "b1", "c1");
        List<String> strList3 = List.copyOf(strList2);
        System.out.println(strList2 == strList3);
        List<String> strList4 = List.copyOf(strings);
        System.out.println(strList4 == strings);

//        List<String> ls = new ArrayList<String>(); // 1
////        List<Object> lo = ls; // 2
//        ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
//        concurrentHashMap.forEach((k, v) -> System.out.println(k + ":" + v));

//        Map<String, String> map = new HashMap<>();
//        map.put("key1", "value1");
//        map.put("key2", "value2");
//        // how to iterate a Map?
//        // 1. Iterating over Map.entrySet() using For-Each loop
//        Set<Map.Entry<String, String>> entries = map.entrySet();
//        for (Map.Entry<String, String> entry : entries) {
//            System.out.println(entry.getKey() + ":" + entry.getValue());
//        }
//        // 2. Iterating using Iterator over Map.entrySet()
//        Iterator<Map.Entry<String, String>> iterator = entries.iterator();
//        while(iterator.hasNext()) {
//            System.out.println(iterator.next().getKey() + ":" + iterator.next().getValue());
//        }
//        // 3. Iterating using forEach method:
//        map.forEach((k, v) -> System.out.println(k + ":" + v));
//
//        // 4. Iterating over keys or values using keySet() and values() methods
//        Set<String> keys = map.keySet();
//        for (String key : keys) { // loop keys to get each value for the key
//            System.out.println(key + ":" + map.get(key));
//        }
//        map.keySet().forEach(System.out::println); // loop keys
//        map.values().forEach(System.out::println); // loop values
    }
}
