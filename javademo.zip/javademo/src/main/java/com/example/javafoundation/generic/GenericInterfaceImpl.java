package com.example.javafoundation.generic;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 11:35 2023/5/23
 * @Modified by lenovo
 **/
public class GenericInterfaceImpl implements GenericInterface {
    @Override
    public String test(String str) {
        return null;
    }

    @Override
    public Object test(Object str) {
        return null;
    }
}
