package com.example.designpattern.callback;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:03 2023/2/19
 * @Modified by lenovo
 **/
public class Callbacks {
    public static void main(String[] args) {
        Callee1 callee1 = new Callee1();
        Callee2 callee2 = new Callee2();
        MyIncrementable.f(callee2);
        Caller caller1 = new Caller(callee1);
        Caller caller2 = new Caller(callee2.getCallbackReference());
        caller1.go();
        caller1.go();
        caller2.go();
        caller2.go();
    }
}
