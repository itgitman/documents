package com.example.designpattern.builder2;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:38 2023/2/19
 * @Modified by lenovo
 **/
// Product
public class Food {
    private String mainCourse;
    private String meat;
    private String vegetable;
    private String soap;

    public Food() {
    }

    public void mainCourse(String val) {
        this.mainCourse = val;
    }

    public void meat(String val) {
        this.meat = val;
    }

    public void vegetable(String val) {
        this.vegetable =  val;
    }

    public void soap(String val) {
        this.soap = val;
    }

    @Override
    public String toString() {
        return "Food{" +
                "mainCourse='" + mainCourse + '\'' +
                ", meat='" + meat + '\'' +
                ", vegetable='" + vegetable + '\'' +
                ", soap='" + soap + '\'' +
                '}';
    }
}
