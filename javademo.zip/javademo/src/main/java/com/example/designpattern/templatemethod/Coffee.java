package com.example.designpattern.templatemethod;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:15 2023/2/22
 * @Modified by lenovo
 **/
public class Coffee {
    /**
     * 每个方法都实现算法的一步
     */
    void prepareRecipe() {
        boilWater(); //same
        brewCoffeeGrids(); //different from Tea
        pourInCup(); //same
        addSugarAndMilk(); //different from Tea
    }

    public void boilWater() {
        System.out.println("Boiled Water");
    }

    public void brewCoffeeGrids() {
        System.out.println("Dripping coffer through filter");
    }

    public void pourInCup() {
        System.out.println("Pouring into cup");
    }

    public void addSugarAndMilk() {
        System.out.println("Adding sugar and milk");
    }
}
