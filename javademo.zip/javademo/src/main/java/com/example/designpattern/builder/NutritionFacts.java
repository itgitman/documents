package com.example.designpattern.builder;

/**
 创建性模式封装了对象是如何创建的
 Builder模式可以一步一步构建复杂对象
意图： 将一个复杂对象与它的表示分离，使得通用的创建过程可以创建不同的表示（presentation）。
场景：
 1. 遇到多构造器参数时考虑用构建器模式 - 参考《Effective Java》
 2. 创建复杂对象的算法应该独立于该对象的组成部分以及它们的装配方式。
    当构造过程必须允许被构造的对象有不同的表示时。
案例：
 1. 阅读器(TextReader)可以将文本转换为不同的格式，解决方案可以给阅读器配置一个转换器 （TextConverter），
 转换器负责转换文本，不同的转换器可以转换成不同格式的文本。
**/
public class NutritionFacts { //重叠构造器
    private final int servingSize; //required
    private final int servings; //required
    private final int calories;
    private final int fat;
    private final int sodium;
    private final int carbohydrate;

    public NutritionFacts(int servingSize, int servings) {
        this(servingSize, servings, 0);
    }

    public NutritionFacts(int servingSize, int servings, int calories) {
        this(servingSize, servings, calories, 0);
    }

    public NutritionFacts(int servings, int servingSize, int caloriesm, int fat) {
        this(servings, servingSize, caloriesm, fat, 0);
    }

    public NutritionFacts(int calories, int fat, int servings, int servingSize, int sodium) {
        this(calories, fat, servings, servingSize, sodium, 0);
    }

    public NutritionFacts(int calories, int servingSize, int servings, int fat, int sodium, int carbohydrate) {
        this.calories = calories;
        this.servingSize = servingSize;
        this.servings = servings;
        this.fat = fat;
        this.sodium = sodium;
        this.carbohydrate = carbohydrate;
    }
}