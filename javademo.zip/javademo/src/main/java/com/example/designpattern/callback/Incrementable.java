package com.example.designpattern.callback;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:54 2023/2/19
 * @Modified by lenovo
 **/
public interface Incrementable {
    void increment();
}
