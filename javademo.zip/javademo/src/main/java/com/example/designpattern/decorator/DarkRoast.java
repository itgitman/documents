package com.example.designpattern.decorator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:30 2023/2/22
 * @Modified by lenovo
 **/
public class DarkRoast extends Beverage {
    public DarkRoast() {
        this.description = "Dark roast coffee ";
    }

    @Override
    public double cost() {
        return 120.0;
    }
}
