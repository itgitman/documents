package com.example.designpattern.command.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 20:44 2023/2/27
 * @Modified by lenovo
 **/
public interface Command {
    void execute();
    void undo();
}
