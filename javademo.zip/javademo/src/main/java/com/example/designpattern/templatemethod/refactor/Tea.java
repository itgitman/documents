package com.example.designpattern.templatemethod.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:15 2023/2/22
 * @Modified by lenovo
 **/
public class Tea extends CaffeineBeverage {

    public void blew() {
        System.out.println("Steeping the tea");
    }

    public void extra() {
        System.out.println("Adding lemon");
    }
}
