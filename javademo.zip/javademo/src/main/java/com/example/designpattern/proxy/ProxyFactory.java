package com.example.designpattern.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * 静态：由程序员创建代理类,
 * 代理对象只服务于一种类型的对象，如果要服务多类型的对象。势必要为每一种对象都进行代理。
 * 代理类和被代理类实现相同的接口，如果接口发生变化，代理类也需要变化
 * 动态：在程序运行时运用反射机制动态创建而成。
 **/
public class ProxyFactory implements InvocationHandler {
    private Object target;

    public ProxyFactory(Object target) {
        this.target = target;
    }

    public Object proxy() {
        return Proxy.newProxyInstance(
                target.getClass().getClassLoader(),
                target.getClass().getInterfaces(),
                this
        );
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("This is a dynamic proxy");
        return method.invoke(target, args);
    }

    public static void main(String[] args) {
        Greeting greeting = new GreetingImpl();

        Greeting greetingProxy = (Greeting)new ProxyFactory(greeting).proxy();

        greetingProxy.sayHi("Jack");

        greetingProxy.getClass().getClassLoader().getResourceAsStream("");
    }
}
