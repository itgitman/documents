package com.example.designpattern.state.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:28 2023/2/25
 * @Modified by lenovo
 **/
public class UnlockedState implements MachineState {
    public void coin(Machine machine) {
        machine.thankyou();
    }
    public void pass(Machine machine) {
        machine.setLocked();
        machine.locked();
    }
}
