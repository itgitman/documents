package com.example.designpattern.command;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 20:50 2023/2/27
 * @Modified by lenovo
 **/
public class Light {
    public void turnOn() {
        System.out.println("Turn on light");
    }

    public void turnOff() {
        System.out.println("Turn off light");
    }
}
