package com.example.designpattern.builder;

//JavaBeans模式
//1. 构造过程被分到几个调用中，在构造过程中JavaBean可能处于不一致的状态。
//2. JavaBean模式阻止将一个类做成不可变的类(immutable class), 有线程安全问题。
public class NutritionFacts1 { //重叠构造器
    private int servingSize = -1;
    private int servings = -1;
    private int calories = 0;
    private int fat = 0;
    private int sodium = 0;
    private int carbohydrate = 0;

    public NutritionFacts1() {
    }

    public void setServingSize(int servingSize) {
        this.servingSize = servingSize;
    }

    public void setServings(int servings) {
        this.servings = servings;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public void setFat(int fat) {
        this.fat = fat;
    }

    public void setSodium(int sodium) {
        this.sodium = sodium;
    }

    public void setCarbohydrate(int carbohydrate) {
        this.carbohydrate = carbohydrate;
    }

    public static void main(String[] args) {
        NutritionFacts1 nutritionFacts1 = new NutritionFacts1();
        nutritionFacts1.setServingSize(240);
        nutritionFacts1.setServingSize(8);
        nutritionFacts1.setCalories(100);
        nutritionFacts1.setSodium(35);
        nutritionFacts1.setCarbohydrate(27);
    }
}