package com.example.designpattern.decorator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:28 2023/2/22
 * @Modified by lenovo
 **/
public abstract class Beverage {
    String description;

    public String getDescription() {
        return description;
    }

    public abstract double cost();
}
