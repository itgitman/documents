package com.example.designpattern.strategy.refactor;

public interface EmployeeType {//strategy interface
	public int payAmount(Employee employee); 
}