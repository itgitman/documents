package com.example.designpattern.command;

import com.example.designpattern.command.refactor.Command;
import com.example.designpattern.command.refactor.Light;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:16 2023/3/2
 * @Modified by lenovo
 **/
public class Controller {
    private Light light;

    public Controller(Light light) {
        this.light = light;
    }

    public void pushOn(String name){
        light.turnOn();
    }

    public void pushOff(String name) {
        light.turnOff();
    }
}
