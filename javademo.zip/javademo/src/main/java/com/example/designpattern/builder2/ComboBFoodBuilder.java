package com.example.designpattern.builder2;

/**
 * 每个具体的builder包含了创建和装配一个特定产品的所有代码
 **/
public class ComboBFoodBuilder implements FoodBuilder {
    private final Food food;
    public ComboBFoodBuilder() {
        this.food = new Food();
    }
    @Override
    public void mainCourse() {
        food.mainCourse("noodle");
    }

    @Override
    public void meat() {
        food.meat("beef");
    }

    @Override
    public void vegetable() {
        food.vegetable("tomato");
    }

    @Override
    public void soap() {
        food.soap("egg soap");
    }

    @Override
    public Food getFood() {
        return food;
    }
}