package com.example.designpattern.state;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:24 2023/2/25
 * @Modified by lenovo
 **/
public class MachineController {
    public void thankyou() {
        System.out.println("thank you");
    }

    public void unlocked() {
        System.out.println("unlocked machine");
    }

    public void locked() {
        System.out.println("locked machine");
    }

    public void alarm() {
        System.out.println("Can't pass as it is locked");
    }
}
