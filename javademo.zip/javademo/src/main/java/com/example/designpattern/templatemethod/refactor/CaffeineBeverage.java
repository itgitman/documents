package com.example.designpattern.templatemethod.refactor;

/**
 * Template Method模式定义一个操作中的算法的骨架，而将一些步骤延迟到子类中。
 * Template Method使得子类可以不改变一个算法的结构即可重定义该算法的某些特定步骤。
 **/
public abstract class CaffeineBeverage {
    //需要进一步抽象化prepareRecipe方法 - 模板方法
    final public void prepareRecipe() {
        boilWater();
        //饮料不同，但都是热水泡咖啡或茶， 相同的功能，不同的实现而已，需要对方法进行抽象
        blew(); //brew
        pourInCup();
        //饮料不同，但都是加配料， 相同的功能，不同的实现而已，需要对方法进行抽象
        extra(); //addCondiments
    }

    protected abstract void extra();

    protected abstract void blew();

    public void boilWater() {
        System.out.println("Boiled Water");
    }

    public void pourInCup() {
        System.out.println("Pouring into cup");
    }

}
