package com.example.designpattern.builder2;

/**
 * 一个抽象的builder为director可能要创建的每个构件定义一个操作
 * 每个具体的builder包含了创建和装配一个特定产品的所有代码
 **/
public interface FoodBuilder {
    void mainCourse();
    void meat();
    void vegetable();
    void soap();
    Food getFood();
}
