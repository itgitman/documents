package com.example.designpattern.command.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 20:48 2023/2/27
 * @Modified by lenovo
 **/
public class TVSetCommand implements Command {
    private TVSet tvSet;

    public TVSetCommand(TVSet tvSet) {
        this.tvSet = tvSet;
    }

    @Override
    public void execute() {
        tvSet.turnOn();
    }

    @Override
    public void undo() {
        tvSet.turnOff();
    }
}
