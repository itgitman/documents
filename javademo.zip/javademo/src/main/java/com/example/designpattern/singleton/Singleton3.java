package com.example.designpattern.singleton;
/**
 * 第三种方式实现singleton, 延迟方式
 */
public class Singleton3 {
	static class SingletonHolder {   
		static Singleton3 instance = new Singleton3();   
	}   
	public static Singleton3 getInstance() {   
		return SingletonHolder.instance;   
	}   
	  
} 
