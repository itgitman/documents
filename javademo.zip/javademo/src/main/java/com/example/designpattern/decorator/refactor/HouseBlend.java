package com.example.designpattern.decorator.refactor;

/**
 * 具体组件(Concrete Component)
 **/
public class HouseBlend extends Beverage {
    public HouseBlend() {
        this.description = "House blend coffee";
    }

    @Override
    public double cost() {
        return 90.0;
    }
}
