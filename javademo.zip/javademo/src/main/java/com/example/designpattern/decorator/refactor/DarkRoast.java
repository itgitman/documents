package com.example.designpattern.decorator.refactor;

/**
 * 具体组件(Concrete Component)
 **/
public class DarkRoast extends Beverage {
    public DarkRoast() {
        this.description = "Dark roast coffee ";
    }

    @Override
    public double cost() {
        return 120.0;
    }
}
