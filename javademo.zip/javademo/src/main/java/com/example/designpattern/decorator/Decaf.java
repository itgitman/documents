package com.example.designpattern.decorator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:30 2023/2/22
 * @Modified by lenovo
 **/
public class Decaf extends Beverage {
    public Decaf() {
        this.description = "Decaf coffee";
    }

    @Override
    public double cost() {
        return 110.0;
    }
}
