package com.example.designpattern.proxy;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:33 2023/3/30
 * @Modified by lenovo
 **/
public interface Greeting {
    void sayHi(String name);
}
