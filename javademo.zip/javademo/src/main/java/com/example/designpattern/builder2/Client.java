package com.example.designpattern.builder2;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 17:00 2023/2/19
 * @Modified by lenovo
 **/
public class Client {
    public static void main(String[] args) {
        ComboAFoodBuilder comboAFoodBuilder = new ComboAFoodBuilder();
        Food food = FoodDirector.createFood(comboAFoodBuilder);
        System.out.println(food);

        ComboBFoodBuilder comboBFoodBuilder = new ComboBFoodBuilder();
        Food food1 = FoodDirector.createFood(comboBFoodBuilder);
        System.out.println(food1);
    }
}
