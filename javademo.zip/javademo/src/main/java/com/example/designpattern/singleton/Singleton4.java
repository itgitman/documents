package com.example.designpattern.singleton;

/**
 * 第四种方式实现singleton
 */
public enum Singleton4 {
	SINGLETON;
	Singleton4() {
		
	}
} 
