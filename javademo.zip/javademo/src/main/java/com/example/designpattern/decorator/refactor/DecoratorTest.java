package com.example.designpattern.decorator.refactor;

/**
 * 测试decorator模式
 **/
public class DecoratorTest {
    public static void main(String[] args) {
        Beverage coffee = new DarkRoast();
        //以Mocha对象装饰DarkRoast对象
        Beverage coffeeWithMocha = new Mocha(coffee);
        System.out.println(coffeeWithMocha.getDescription() + ": " + coffeeWithMocha.cost());
        //以Soy对象再次封装
        Beverage coffeeWithMochaAndSoy = new Soy(coffeeWithMocha);
        System.out.println(coffeeWithMochaAndSoy.getDescription() + ":" + coffeeWithMochaAndSoy.cost());
    }
}
