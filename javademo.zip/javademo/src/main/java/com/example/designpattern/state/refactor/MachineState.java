package com.example.designpattern.state.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:32 2023/2/25
 * @Modified by lenovo
 **/
public interface MachineState {
    void coin(Machine machine);
    void pass(Machine machine);
}
