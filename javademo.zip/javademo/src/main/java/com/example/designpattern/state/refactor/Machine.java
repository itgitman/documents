package com.example.designpattern.state.refactor;

/**
 * State design pattern:
 * 允许一个对象在其内部状态改变时改变它的行为。对象看起来似乎修改了它所属的类。
 **/
public class Machine {
//    若状态机在lock状态收到一个coin事件，状态改变成unlocked状态并执行unlock动作；
//    若状态机在unlock状态再收到一个coin事件，状态不变显示”thank you”;
//    若状态机在unlock状态收到一个pass事件，状态改变成locked状态并执行lock动作；
//    若状态机在lock状态收到一个pass事件，状态不变并报警。

//    private final int LOCKED = 0;
//    private final int UNLOCKED = 1;
//    private int state = LOCKED;
    public static final MachineState lockedState = new LockedState();
    public static final MachineState unlockedState = new UnlockedState();
    private MachineState state = lockedState;
    private MachineController machineController;

    public Machine(MachineController machineController) {
        this.machineController = machineController;
    }

    /**
     * 投币事件
     */
    public void coin() {
        state.coin(this);
//        if(state == LOCKED) {
//            state = UNLOCKED;
//            this.unlocked();
//        } else {
//            this.thankyou();
//        }
    }

    /**
     * 通过事件
     */
    public void pass() {
        state.pass(this);
//        if(state == LOCKED) {
//            this.alarm();
//        } else {
//            state = LOCKED;
//            locked();
//        }
    }

    public void thankyou() {
        machineController.thankyou();
    }

    public void unlocked() {
        machineController.unlocked();
    }

    public void locked() {
        machineController.locked();
    }

    public void alarm() {
        machineController.alarm();
    }

    public void setUnlocked() {
        state = this.unlockedState;
    }
    public void setLocked() {
        state = this.lockedState;
    }
}
