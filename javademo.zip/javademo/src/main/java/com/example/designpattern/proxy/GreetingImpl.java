package com.example.designpattern.proxy;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:34 2023/3/30
 * @Modified by lenovo
 **/
public class GreetingImpl implements Greeting {
    @Override
    public void sayHi(String name) {
        System.out.println("Hi " + name);
    }
}
