package com.example.designpattern.decorator.refactor;

/**
 * 具体组件(Concrete Component)
 **/
public class Espresso extends Beverage {
    public Espresso() {
        this.description = "Espresso coffee";
    }

    @Override
    public double cost() {
        return 100.0;
    }
}
