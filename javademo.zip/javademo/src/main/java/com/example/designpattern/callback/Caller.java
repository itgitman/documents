package com.example.designpattern.callback;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 8:01 2023/2/19
 * @Modified by lenovo
 **/
public class Caller {
    private Incrementable callbackReference;
    public Caller(Incrementable inc) {
        this.callbackReference = inc;
    }
    public void go() {
        callbackReference.increment();
    }
}
