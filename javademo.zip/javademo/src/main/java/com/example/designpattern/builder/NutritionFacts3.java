package com.example.designpattern.builder;

//Builder模式2
public class NutritionFacts3 { //重叠构造器
    private final int servingSize;
    private final int servings;
    private int calories;
    private int fat;
    private int sodium;
    private int carbohydrate;
    private NutritionFacts3(int servingSize, int servings) {
        this.servingSize = servingSize;
        this.servings = servings;
    }
    public static NutritionFacts3 withService(int servingSize, int servings) {
        return new NutritionFacts3(servingSize, servings);
    }

    public NutritionFacts3 withSodium(int sodium) {
        this.sodium = sodium;
        return this;
    }

    public NutritionFacts3 withCarbohydrate(int carbohydrate) {
        this.carbohydrate = carbohydrate;
        return this;
    }

    public NutritionFacts3 withCalories(int calories) {
        this.calories = calories;
        return this;
    }

    public NutritionFacts3 withFat(int fat) {
        this.fat = fat;
        return this;
    }

    public static void main(String[] args) {
        NutritionFacts3 cocaCola = NutritionFacts3.withService(240, 8)
                .withCalories(100)
                .withFat(35)
                .withCarbohydrate(120);
    }
}