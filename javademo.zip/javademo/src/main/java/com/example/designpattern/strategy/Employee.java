package com.example.designpattern.strategy;

import java.util.function.Function;

/**
 *
 */
public class Employee {
    public static final int ENGINEER = 0;
    public static final int SALESMAN = 1;
    public static final int MANAGER  = 2;
    //根据type成员变量对封装算法，抽象接口，每个type是一个算法的实现
    private int type = 0;
    private int monthlySalary;
    private int commission;
    private int bonus;
    public Employee(int type, int monthlySalary) {
        this.type = type;
        this.monthlySalary = monthlySalary;
    }
    public int getType() {
        return type;
    }
    public int getMonthlySalary() {
        return monthlySalary;
    }
    public int getCommission() {
        return commission;
    }
    public void setCommission(int commission) {
        this.commission = commission;
    }
    public int getBonus() {
        return bonus;
    }
    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    // if-else or switch statement, 变化的部分，
    // violate open-closed principle
    public int payAmount() {
        int result = 0;
        switch(type) {
            case ENGINEER:
                result = monthlySalary;
                break;
            case SALESMAN:
                result = monthlySalary + commission;
                break;
            case MANAGER:
                result = monthlySalary + bonus;
                break;
        }
        return result;
    }

    public int payAmount2(Function<Employee, Integer> func) {
        return func.apply(this);
    };

    public static void main(String[] args) {
        Employee engineer = new Employee(Employee.ENGINEER, 5000);
        System.out.println(engineer.payAmount());
        engineer.payAmount2( e->e.getMonthlySalary());

        Employee manager = new Employee(Employee.MANAGER, 5000);
        manager.setBonus(2000);
        engineer.payAmount2(e->e.getMonthlySalary() + e.getBonus());
    }
}
