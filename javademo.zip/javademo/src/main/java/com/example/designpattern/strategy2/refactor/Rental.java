package com.example.designpattern.strategy2.refactor;

import com.example.designpattern.strategy2.refactor.Movie;

public class Rental {

    private Movie movie;

    private int daysRented;

    public Rental(Movie movie, int daysRented) {
        this.movie = movie;
        this.daysRented = daysRented;
    }

    public int getDaysRented() {
        return daysRented;
    }

    public Movie getMovie() {
        return movie;
    }

    double getCharge() {
        return movie.getCharge(daysRented);
    }

    int getFrequentRenterPoint() {
        return movie.getFrequentRenterPoints(daysRented);
    }
}