package com.example.designpattern.singleton;

/**
 * 第二种方式实现singleton， 延迟实例化方式, 在多线程环境下需要同步
 */
public class Singleton2 {
	private static Singleton2 instance;
	private Singleton2() {
	}
	public synchronized static Singleton2 newInstance() {
		if(instance == null) {
			instance =  new Singleton2();
		} 
		return instance;
	}
}
