package com.example.designpattern.callback;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:56 2023/2/19
 * @Modified by lenovo
 **/
public class MyIncrementable {
    public void increment() {
        System.out.println("other operations");
    }
    public static void f(MyIncrementable mi) {
        mi.increment();
    }
}
