package com.example.designpattern.callback;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:58 2023/2/19
 * @Modified by lenovo
 **/
public class Callee2 extends MyIncrementable {
    private int i = 0;
    public void increment() {
        super.increment();
        i++;
        System.out.println(i);
    }
    //内部类实现了Incrementable, 它提供了返回Callee2 的Hook(钩子)
    //闭包 Closure是一个可调用的对象，它记录一些信息，这些信息来自于创建它的作用域
    private class Closure implements Incrementable {

        @Override
        public void increment() {
            Callee2.this.increment();
        }
    }

    Incrementable getCallbackReference() {
        return new Closure();
    }
}
