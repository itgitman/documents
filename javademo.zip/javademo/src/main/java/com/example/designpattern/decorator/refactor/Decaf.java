package com.example.designpattern.decorator.refactor;

/**
 * 具体组件(Concrete Component)
 **/
public class Decaf extends Beverage {
    public Decaf() {
        this.description = "Decaf coffee";
    }

    @Override
    public double cost() {
        return 110.0;
    }
}
