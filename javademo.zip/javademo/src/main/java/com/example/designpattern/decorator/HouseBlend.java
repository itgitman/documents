package com.example.designpattern.decorator;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:30 2023/2/22
 * @Modified by lenovo
 **/
public class HouseBlend extends Beverage {
    public HouseBlend() {
        this.description = "House blend coffee";
    }

    @Override
    public double cost() {
        return 90.0;
    }
}
