package com.example.designpattern.strategy.refactor;

public class Engineer implements EmployeeType {
	public int payAmount(Employee employee) {
		return employee.getMonthlySalary();// monthlySalary
	}
}