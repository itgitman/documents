package com.example.designpattern.singleton;

/**
 * 第一种方式实现singleton
 */
public class Singleton {
	private static Singleton instance = new Singleton();
	private Singleton() {
	}
	public static Singleton newInstance() {
		return instance;
	}
}
