package com.example.designpattern.builder2;

/**
 * 创建性模式封装了对象是如何创建的。将对象的创建与使用分离。
 * 导向器Director 控制一步一步构造产品
 * 1. 使你可以改变一个产品的内在表示，产品通过builder的抽象接口构造的，
 * 如果要改变一个产品的内部表示，只需要定义一个新的生产器。
 * 2. 将构造代码和表示分离。 每个具体的builder包含了创建和装配一个特定产品的所有代码。
 * 这些代码只要写一次，可以被不同的director复用。 Builder 独立于 Director
 * 3. 对构造过程精细的控制。在Director控制下一步一步构造产品。
 **/
public class TakeAwayFoodDirector {
    public static Food createTakeAwayFood(FoodBuilder foodBuilder) {
        foodBuilder.mainCourse();
        foodBuilder.vegetable();
        return foodBuilder.getFood();
    }
}
