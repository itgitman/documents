package com.example.designpattern.abstractfactory;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:33 2023/2/19
 * @Modified by lenovo
 **/
public interface Coat {
}
