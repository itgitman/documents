package com.example.designpattern.strategy.refactor;

public class Manager implements EmployeeType {
	public int payAmount(Employee employee) {
		return employee.getMonthlySalary() + employee.getBonus();
	}
}
