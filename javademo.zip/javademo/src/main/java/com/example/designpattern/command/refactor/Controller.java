package com.example.designpattern.command.refactor;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 20:44 2023/2/27
 * @Modified by lenovo
 **/
public class Controller {
    private Map<String, Command> commands = new HashMap<>();
    public void pushOnButton(String obj) {
        commands.get(obj).execute();
    }
    public void pushOffButton(String obj) {
        commands.get(obj).undo();
    }
    public void addCommand(String commandName, Command command) {
        commands.put(commandName, command);
    }

    public static void main(String[] args) {
        Controller controller = new Controller();
        controller.addCommand("LightCommand", new LightCommand(new Light()));
        controller.addCommand("TVSetCommand", new TVSetCommand(new TVSet()));
        controller.pushOnButton("LightCommand");
        controller.pushOffButton("LightCommand");
        controller.pushOnButton("TVSetCommand");
        controller.pushOffButton("TVSetCommand");
    }
}
