package com.example.designpattern.templatemethod;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:15 2023/2/22
 * @Modified by lenovo
 **/
public class Tea {
    /**
     * 每个方法都实现算法中的一步
     */
    public void prepareRecipe() {
        boilWater(); //same
        steepTeaTag();//different from Coffee
        pourInCup(); //same
        addLemon(); //different from Coffee
    }

    public void boilWater() {
        System.out.println("Boiled Water");
    }

    public void steepTeaTag() {
        System.out.println("Steeping the tea");
    }

    public void pourInCup() {
        System.out.println("Pouring into cup");
    }

    public void addLemon() {
        System.out.println("Adding lemon to tea");
    }
}
