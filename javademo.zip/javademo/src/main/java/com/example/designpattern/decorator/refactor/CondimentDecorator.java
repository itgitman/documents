package com.example.designpattern.decorator.refactor;

/**
 * 装饰器(Decorator), also known as Wrapper
 * 动态地给一个对象添加一些额外的职责，就增加功能来说，Decorator模式比生成子类更为灵活
 * 每个装饰器都"有一个(has a)"  组件(component)，也就是装饰者有个实例变量以保存某个Component的引用。
 **/
public abstract class CondimentDecorator extends Beverage {
    Beverage beverage;
//    public abstract String getDescription();
}
