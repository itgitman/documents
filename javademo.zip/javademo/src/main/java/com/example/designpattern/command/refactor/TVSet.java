package com.example.designpattern.command.refactor;

import com.example.modeling1.refactor.Switchable;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 20:49 2023/2/27
 * @Modified by lenovo
 **/
public class TVSet {
    public void turnOn() {
        System.out.println("Turn on TV set");
    }

    public void turnOff() {
        System.out.println("Turn off TV set");
    }
}
