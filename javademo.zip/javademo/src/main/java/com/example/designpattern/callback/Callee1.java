package com.example.designpattern.callback;

import javax.sound.midi.Soundbank;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:55 2023/2/19
 * @Modified by lenovo
 **/
public class Callee1 implements Incrementable {
    private int i = 0;
    @Override
    public void increment() {
        i++;
        System.out.println(i);
    }
}
