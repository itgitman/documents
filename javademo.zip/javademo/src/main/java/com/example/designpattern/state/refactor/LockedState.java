package com.example.designpattern.state.refactor;

import javax.crypto.Mac;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:28 2023/2/25
 * @Modified by lenovo
 **/
public class LockedState implements MachineState {
    public void coin(Machine machine) {
        machine.setUnlocked();
        machine.unlocked();
    }

    public void pass(Machine machine) {
        machine.alarm();
    }
}
