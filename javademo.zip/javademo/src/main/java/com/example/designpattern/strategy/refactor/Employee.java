package com.example.designpattern.strategy.refactor;

/**
 * Context
 * 1.策略模式： 封装算法，定义一系列的算法，把它们分别封装起来，并且使它们可以互相替换。
 * 使得算法可以独立于使用它的客户而独立变化。
 * 2. 案例：对公司员工的薪酬策略抽象建模
 * 3. 思考为什么不用类继承，而是对象的组合？
 **/
public class Employee {
//    public static final int ENGINEER = 0;
//    public static final int SALESMAN = 1;
//    public static final int MANAGER  = 2;
//
//    private int type = 0;
    //Employee has an EmployeeType
    private EmployeeType employeeType;
    private int monthlySalary;
    private int commission;
    private int bonus;
//    public Employee(int type, int monthlySalary)
    public Employee(EmployeeType employeeType, int monthlySalary) {
        this.employeeType = employeeType;
        this.monthlySalary = monthlySalary;
    }
    // 对象的组合，将计算pay amount的任务委托(delegate)给对象EmployeeType
    public int payAmount() {
//        int result = 0;
//        switch(type) {
//            case ENGINEER:
//                result = monthlySalary;
//                break;
//            case SALESMAN:
//                result = monthlySalary + commission;
//                break;
//            case MANAGER:
//                result = monthlySalary + bonus;
//                break;
//        }
//        return result;
        return employeeType.payAmount(this);
    }

    public EmployeeType getType() {
        return employeeType;
    }

    public int getMonthlySalary() {
        return monthlySalary;
    }

    public int getCommission() {
        return commission;
    }

    public void setCommission(int commission) {
        this.commission = commission;
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public static void main(String[] args) {
        EmployeeType employeeType = new Engineer();
        Employee engineer = new Employee(e->e.getMonthlySalary(), 5000);
        System.out.println(engineer.payAmount());

        Employee manager = new Employee(e->e.getMonthlySalary() + e.getBonus(), 5000);
        manager.setBonus(2000);
        System.out.println(manager.payAmount());
    }
}

