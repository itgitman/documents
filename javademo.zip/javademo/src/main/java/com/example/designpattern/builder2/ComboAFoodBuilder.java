package com.example.designpattern.builder2;

/**
 * 每个具体的builder包含了创建和装配一个特定产品的所有代码
 **/
public class ComboAFoodBuilder implements FoodBuilder {
    private Food food;
    public ComboAFoodBuilder() {
        this.food = new Food();
    }
    @Override
    public void mainCourse() {
        food.mainCourse("rice");
    }

    @Override
    public void meat() {
        food.meat("pork");
    }

    @Override
    public void vegetable() {
        food.vegetable("cabbage");
    }

    @Override
    public void soap() {
        food.soap("chicken soap");
    }

    @Override
    public Food getFood() {
        return food;
    }
}
