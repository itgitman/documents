package com.example.designpattern.decorator.refactor;

/**
 * 抽象组件(Component)， 可以是抽象类或接口
 **/
public abstract class Beverage {
    String description = "Unknown Beverage";

    public String getDescription() {
        return description;
    }

    public abstract double cost();
}
