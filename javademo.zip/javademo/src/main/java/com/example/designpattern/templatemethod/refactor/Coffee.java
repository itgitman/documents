package com.example.designpattern.templatemethod.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:15 2023/2/22
 * @Modified by lenovo
 **/
public class Coffee extends CaffeineBeverage {

    public void blew() {
        System.out.println("Dripping coffee through filter");
    }
    public void extra() {
        System.out.println("Adding sugar and milk to coffee");
    }
}
