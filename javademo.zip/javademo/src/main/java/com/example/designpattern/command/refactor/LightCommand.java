package com.example.designpattern.command.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:22 2023/3/12
 * @Modified by lenovo
 **/
public class LightCommand implements Command {
    private Light light;

    public LightCommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOn();
    }

    @Override
    public void undo() {
        light.turnOff();
    }
}
