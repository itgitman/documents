package com.example.gc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 下面案例评估： 对数据库中的信用卡进行贷款评估。该程序执行一定时间后可能频繁FullGC，然后OOM。查询什么原因。
 * 启动参数：-XX:+PrintGC  -Xms200M -Xmx200M
 *
 * @author 诸葛小猿
 * @date 2021-03-06
 */
public class JVMTest1 {
    /**
     * 线程池
     */
    public static ScheduledThreadPoolExecutor executor =
            new ScheduledThreadPoolExecutor(50, new ThreadPoolExecutor.DiscardOldestPolicy());

    /**
     * main方法
     *
     * @param args
     */
    public static void main(String[] args) throws Exception {
        executor.setMaximumPoolSize(50);

        // 死循环 每次去100条数
        for (; ; ) {
            modFit();
            Thread.sleep(100);
        }
    }

    /**
     * 模型匹配
     */
    public static void modFit() {
        // 取100条数据
        List<CardInfo> list = getAllCard();

        list.forEach(cardInfo -> {
            // to do something
            executor.scheduleWithFixedDelay(() -> {
                cardInfo.m();
            }, 2, 3, TimeUnit.SECONDS);
        });
    }

    /**
     * 每次从数据库中获得100个行用卡信息
     */
    public static List<CardInfo> getAllCard() {
        List<CardInfo> list = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            list.add(new CardInfo());
        }
        return list;
    }

    /**
     * 模拟一张行用卡，
     * 里面有个空的m()
     */
    public static class CardInfo {
        BigDecimal price = new BigDecimal(0.0);
        String name = "张三";
        int age = 30;
        Date birthDate = new Date();

        public void m() {

        }
    }
}
