package com.example.multiplethread.quiz;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 两个线程轮流打印1-100, 输出123456789...
 * Thread numbers flag  nextFlag(flag=!flag)
 * t1  1  3  5  odd  even
 * t2  2  4  6  even odd
 **/
public class OddEvenPrintWithLock {
    private int maxNumber = 10;
    private static int number = 1; //全局变量
    private boolean flag = true;

    public OddEvenPrintWithLock(int maxNumber) {
        this.maxNumber = maxNumber;
    }

    private ReentrantLock lock = new ReentrantLock();
    private Condition condition = lock.newCondition();

    public void print(boolean isEven) {
        lock.lock();
        try {
            while (number < maxNumber) {
                while (flag != isEven) {
                    try {
                        condition.await();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println(Thread.currentThread().getName() + ": " + number++);
                flag = !flag;
                condition.signal();
            }

        } finally {
            lock.unlock();
        }
    }

    public static void main(String[] args) {
        OddEvenPrintWithLock task = new OddEvenPrintWithLock(100);
        new Thread(() -> task.print(true), "Odd Thread: ").start();
        new Thread(() -> task.print(false), "Even Thread: ").start();
    }
}
