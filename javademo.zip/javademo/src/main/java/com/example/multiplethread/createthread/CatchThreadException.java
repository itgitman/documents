package com.example.multiplethread.createthread;

import javax.sound.midi.Soundbank;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:18 2023/3/14
 * @Modified by lenovo
 **/
public class CatchThreadException {
    public static void main(String[] args) {
        Thread thread = new Thread(()-> System.out.println(1/0));
        thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                System.out.println("error: " + e.getMessage());
            }
        });
        thread.start();
    }
}
