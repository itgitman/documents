package com.example.multiplethread.createthread;

import java.util.concurrent.TimeUnit;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 13:42 2023/3/13
 * @Modified by lenovo
 **/
public class ThreadIntercept {
    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                    System.out.println("hello, world!");
                } catch (InterruptedException e) {
                    System.out.println("intercepted");
                }
            }
        });
        thread.start();
        TimeUnit.MICROSECONDS.sleep(1);
        System.out.println(thread.isInterrupted());
        //中断方法并不能终止线程，只是将线程的中断标记设置为true.
        thread.interrupt();
        System.out.println(thread.isInterrupted());
        TimeUnit.SECONDS.sleep(2);
        System.out.println(thread.isInterrupted());
    }
}
