package com.example.multiplethread.quiz;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;

/**
 * 两个线程轮流打印1-100, 输出123456789...
 * 如果程序中只存在代码中创建的两个线程，这个程序运行始终正确
 **/
public class OddEvenPrintWithLockSupport {
    private static Thread t1, t2;
    private int maxNumber = 10;
    private static int number = 1; //全局变量


    public OddEvenPrintWithLockSupport(int maxNumber) {
        this.maxNumber = maxNumber;
    }

    public void print(Thread t) {
        while (number < maxNumber) {
            try {
                TimeUnit.MILLISECONDS.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            LockSupport.park();
            System.out.println(Thread.currentThread().getName() + ": " + number++);
            LockSupport.unpark(t);
        }
    }

    public static void main(String[] args) {
        OddEvenPrintWithLockSupport task = new OddEvenPrintWithLockSupport(101);
        t1 = new Thread(() -> task.print(t2), "Odd Thread: ");
        t2 = new Thread(() -> task.print(t1), "Even Thread: ");
        t1.start();
        t2.start();
        LockSupport.unpark(t1);
    }
}
