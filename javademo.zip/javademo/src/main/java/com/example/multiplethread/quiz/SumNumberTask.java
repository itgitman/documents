package com.example.multiplethread.quiz;

/**
 * 编写10个线程，
 * 第一个线程从1加到10，第二个线程从11加20…第十个线程从91加到100，
 * 最后再把10个线程结果相加。
 **/
public class SumNumberTask extends Thread {
    private int start = 0;
    private int factor = 0;
    private int sum = 0;

    public SumNumberTask(int i, int factor) {
        this.start = i;
        this.factor = factor;
    }

    @Override
    public void run() {
        for (int i = start; i < start + factor; i++) {
            sum += i;
        }
    }

    public int getSum() {
        return sum;
    }

    public static void main(String[] args) {
        int total = 0;
        int factor = 10;
        for (int i = 0; i < 10; i++) {
            SumNumberTask t1 = new SumNumberTask(i * factor + 1, factor);
            t1.start();
            try {
                t1.join();
                System.out.println(t1.getSum());
                total += t1.getSum();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(total);
    }
}
