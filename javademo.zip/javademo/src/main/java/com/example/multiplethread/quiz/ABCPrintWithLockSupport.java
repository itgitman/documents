package com.example.multiplethread.quiz;

import java.util.concurrent.locks.LockSupport;

/**
 * wait, notify and notifyAll必须配合Object Monitor一起使用； 而LockSupport的pack和unpack不需要
 * LockSupport的unpack指定线程，notify随机唤醒
 * LockSupport 可以先unpack, 而notify & notifyAll不能先执行
 * 使用三个线程交替打印A，B，C； 打印顺序是ABCABCABC...
 * Thread,  String, wait flag, next flag
 * t1  A, 0, 1
 * t2  B, 1, 2
 * t3  c, 2, 0
 */
public class ABCPrintWithLockSupport {
    static Thread t1 , t2, t3;
    private int number;

    public ABCPrintWithLockSupport(int number) {
        this.number = number;
    }

    public void print(String str, Thread nextThread) {
        for (int i = 0; i < 10; i++) {
            LockSupport.park(); //为线程调度目的禁用当前线程，除非许可可用。
            System.out.print(str);
            LockSupport.unpark(nextThread);
        }
    }

    public static void main(String[] args) {
        ABCPrintWithLockSupport task = new ABCPrintWithLockSupport(10);
        //lambda表达式可以访问实例变量或全局变量(static)， 但是如果是局部变量，局部变量一定是事实final的
        t1 = new Thread(() -> task.print("a", t2));
        t2 = new Thread(() -> task.print("b", t3));
        t3 = new Thread(() -> task.print("c", t1));
        t1.start();
        t2.start();
        t3.start();
        LockSupport.unpark(t1);
    }
}
