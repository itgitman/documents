package com.example.multiplethread.quiz;

import java.util.concurrent.CountDownLatch;

/**
 * 编写10个线程，
 * 第一个线程从1加到10，第二个线程从11加20…第十个线程从91加到100，
 * 最后再把10个线程结果相加。
 **/
public class SumNumberTask2 {
    private int sum = 0;
    private CountDownLatch countDownLatch = new CountDownLatch(10);

    public int sum() {
        for (int i = 0; i < 10; i++) {
            int count = i;
            new Thread(() -> {
                int part = 0;
                for (int j = count * 10 + 1; j <= (count + 1) * 10; j++) {
                    part = part + j;
                }
                sum += part;
                countDownLatch.countDown();
                System.out.println(Thread.currentThread().getName() + ": " + part);
            }).start();
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return sum;
    }

    public static void main(String[] args) throws InterruptedException {
        SumNumberTask2 task = new SumNumberTask2();
        System.out.println(task.sum());
    }

}
