package com.example.multiplethread;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 6:10 2023/5/3
 * @Modified by lenovo
 **/
public class ReentrantLockDemo {
    final private Lock lock = new ReentrantLock();
    final private Condition condition = lock.newCondition();
    private int count = 0;

    public void sync() {
        try {
            lock.lock();
            count++;
            System.out.println(Thread.currentThread().getName() + ": " + count);
//            TimeUnit.SECONDS.sleep(1);
//            condition.signal();
//            if(count < 100) {
//                condition.await();
//            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }

    public static void main(String[] args) {
        ReentrantLockDemo demo = new ReentrantLockDemo();
        for (int i = 0; i < 10; i++)
            new Thread(() -> demo.sync()).start();
    }
}
