package com.example.multiplethread.createthread;

import com.example.multiplethread.ThreadSafe;

import java.util.concurrent.TimeUnit;

/**
 * 线程的创建和调用都是有开销的
 * 多线程模拟银行叫号窗口
 * Runnable 对象看做任务(task)
 * Thread 对象看做工人(worker)
 **/
@ThreadSafe
public class TicketWindowRunnable implements Runnable {
    private int index = 1;
    private final static int MAX = 1000;

    @Override
    public void run() {
        while (true) {
            synchronized (this) {
                if (index <= MAX) {
                    try {
                        //Thread.sleep(1000);
                        TimeUnit.MILLISECONDS.sleep(200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName() + " number is " + index++);
                } else {
                    break;
                }
            }
        }
    }

    public static void main(String[] args) {
        //多线程共享的对象task
        TicketWindowRunnable task = new TicketWindowRunnable();
        Thread windowThread1 = new Thread(task, "Window1");
        Thread windowThread2 = new Thread(task, "Window2");
        Thread windowThread3 = new Thread(task, "Window3");
        Thread windowThread4 = new Thread(task, "Window4");
        windowThread1.start();
        windowThread2.start();
        windowThread3.start();
        windowThread4.start();
    }
}
