package com.example.multiplethread.quiz;

/**
 * 使用三个线程交替打印A，B，C； 打印顺序是ABCABCABC...
 * Thread,  String, wait flag, next flag
 * t1  A, 0, 1
 * t2  B, 1, 2
 * t3  c, 2, 0
 */
public class ABCPrint {
    private int count; //打印次数
    private int flag; //初始标记

    public ABCPrint(int count, int flag) {
        this.count = count;
        this.flag = flag;
    }

    public void print(String s, int currentFlag, int nextFlag) {
        for (int i = 0; i < count; i++) { //每个线程要循环打印
            synchronized (this) { //add lock
                //while loop (can not use if-else condition)
                while (this.flag != currentFlag) { //标记不同则等待， 条件不一致
                    try {
                        wait(); //当前线程等待
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.print(s);
                this.flag = nextFlag; //改变状态
                notifyAll(); //唤醒其他线程
            }
        }
    }

    public static void main(String[] args) {
        ABCPrint task = new ABCPrint(5, 0);
        Thread t1 = new Thread(() -> task.print("a", 0, 1));
        Thread t2 = new Thread(() -> task.print("b", 1, 2));
        Thread t3 = new Thread(() -> task.print("c", 2, 0));
        t1.start();
        t2.start();
        t3.start();
    }
}