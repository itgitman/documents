package com.example.multiplethread.quiz;

/**
 * 交替打印两个长度一样的数组, 输出1 2 3 4 5 6 7 8 9 10
 * int[] arr1 = new int[]{1, 3, 5, 7, 9};
 * int[] arr2 = new int[]{2, 4, 6, 8, 10};
 **/
public class TwoArrayPrint {
    private int[] arr1 = new int[]{1, 3, 5, 7, 9};
    private int[] arr2 = new int[]{2, 4, 6, 8, 10};
    private boolean flag = true;

    public void print(boolean currFlag) {
        synchronized (this) {
            for (int i = 0; i < arr1.length; i++) {
                while (flag != currFlag) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if (currFlag)
                    System.out.println(Thread.currentThread().getName() + ": " + arr1[i]);
                else
                    System.out.println(Thread.currentThread().getName() + ": " + arr2[i]);
                flag = !flag;
                notify();
            }
        }
    }

    public static void main(String[] args) {
        TwoArrayPrint task = new TwoArrayPrint();
        new Thread(() -> task.print(true)).start();
        new Thread(() -> task.print(false)).start();
    }
}
