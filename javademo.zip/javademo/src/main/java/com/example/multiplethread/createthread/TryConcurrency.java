package com.example.multiplethread.createthread;

import java.util.concurrent.TimeUnit;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:36 2023/3/13
 * @Modified by lenovo
 **/
public class TryConcurrency {
    public static void enjoyMusic() {
        for(;;) {
            System.out.println("enjoy music");
            try {
                TimeUnit.SECONDS.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void watchTVShow() {
//        for(;;) {
            System.out.println("watch TV show");
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
//        }
    }

    public static void main(String[] args) {
        Thread t = new Thread(TryConcurrency::watchTVShow);
        t.start();
        try {
            t.join(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        enjoyMusic();
    }
}
