package com.example.multiplethread.createthread;

import com.example.designpattern.templatemethod.refactor.CaffeineBeverage;

import java.util.concurrent.*;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:45 2023/3/14
 * @Modified by lenovo
 **/
public class CallableDemo {
    public static void main(String[] args) {
        Callable<String> callable = () -> "abc";
        Runnable runnable = () -> System.out.println("hello");
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        Future<String> result = executorService.submit(callable);
        Future<?> submit = executorService.submit(runnable);
        try {
            System.out.println(result.get());
            System.out.println(submit.get()); //return null
        } catch (InterruptedException e) {
            result.cancel(true);
        } catch (ExecutionException e) {
            result.cancel(true);
        } finally {
            executorService.shutdownNow();
        }
    }
}
