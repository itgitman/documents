package com.example.multiplethread.quiz;

/**
 * 写两个线程，一个线程打印1~ 52，另一个线程打印A~Z，打印顺序是12A34B...5152Z
 **/
public class NumberCharPrint {
    private boolean flag = true; //初始状态
    public void print(boolean isNum) {
        int count = 0;
        synchronized (this) {
            for (int i = 0; i < 26 ; i++) {
                while (flag != isNum) { //如果传入的标记和当前对象的状态标记不同，则等待
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                if(isNum) { //打印数字
                    System.out.print(++count);
                    System.out.print(++count);
                } else { //打印字母
                    System.out.print((char)('A' + i));
                }
                flag = !flag; //改变状态控制多线程的交替执行
                notify();
            }
        }
    }

    public static void main(String[] args) {
        NumberCharPrint task = new NumberCharPrint();
        new Thread(()->task.print(true), "Number").start();
        new Thread(()->task.print(false), "Character").start();
    }
}
