package com.example.multiplethread.quiz;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TicketWindows implements Runnable{
    private  int count = 1000;     //票数
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() +": Starting...");
        while(true){
            synchronized (this) {
                if(count > 0){
                    System.out.println(Thread.currentThread().getName() +": Sold one, left "+ --count +" tickets");
                }else{
                    System.out.println(Thread.currentThread().getName() + ": Sold out");
                    break;
                }
            }
        }
        System.out.println(Thread.currentThread().getName() +": Ended...");
    }

    public static void main(String[] args) throws Exception {
    	//创建一个线程对象
		TicketWindows task = new TicketWindows();
		//运行一个线程，代表运行一个售票窗口
        ExecutorService executorService = Executors.newFixedThreadPool(3);
        for (int i = 0; i < 10 ; i++) {
            executorService.submit(task);
        }
        executorService.shutdownNow();
	}
}
