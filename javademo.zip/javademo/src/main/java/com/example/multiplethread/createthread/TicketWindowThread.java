package com.example.multiplethread.createthread;

import com.example.multiplethread.NotThreadSafe;

import java.util.concurrent.TimeUnit;

/**
 * 多线程模拟银行叫号窗口
 * 非线程安全的类
 **/
@NotThreadSafe
public class TicketWindowThread extends Thread {
    //static变量在线程间数据共享
    private static int index = 1;
    private final static int MAX = 1000;

    public TicketWindowThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        while (index <= MAX) { //race condition 竞争条件
            // index++ is not an atomic operation 不是原子操作
            System.out.println(Thread.currentThread().getName() + " number is " + index++);
            try {
                TimeUnit.MICROSECONDS.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        Thread windowThread1 = new TicketWindowThread("Window1");
        Thread windowThread2 = new TicketWindowThread("Window2");
        Thread windowThread3 = new TicketWindowThread("Window3");
        Thread windowThread4 = new TicketWindowThread("Window4");
        windowThread1.start();
        windowThread2.start();
        windowThread3.start();
        windowThread4.start();
    }
}
