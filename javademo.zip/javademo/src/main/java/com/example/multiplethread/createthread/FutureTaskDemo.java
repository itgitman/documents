package com.example.multiplethread.createthread;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:52 2023/3/14
 * @Modified by lenovo
 **/
public class FutureTaskDemo {
    public static void main(String[] args) {
        //1. FutureTask & Thread
        FutureTask<String> futureTask = new FutureTask<>(() -> "future task");
        new Thread(futureTask).start();
        try {
            System.out.println(futureTask.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        //2. FutureTask and ThreadPool
        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(futureTask);
        try {
            System.out.println(futureTask.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } finally {
            executorService.shutdownNow();
        }
    }
}
