package com.example.multiplethread.quiz;

import java.util.concurrent.*;

/**
 * 编写10个线程，
 * 第一个线程从1加到10，第二个线程从11加20…第十个线程从91加到100，
 * 最后再把10个线程结果相加。
 **/
public class SumNumberTask1 implements Callable<Integer> {
    private int start = 0;
    private int end = 0;

    public SumNumberTask1(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public Integer call() throws Exception {
        int sum = 0;
        for (int i = start; i < end; i++) {
            sum += i;
        }
        return sum;
    }

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(10);
        int total = 0;
        for (int i = 0; i < 10; i++) {
            int start = 10 * i + 1;
            int end = start + 10;
            SumNumberTask1 task = new SumNumberTask1(start, end);
            Future<Integer> submit = executorService.submit(task);
            try {
                total += submit.get();
//                System.out.println(total);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
        System.out.println(total);
        executorService.shutdownNow();
    }
}
