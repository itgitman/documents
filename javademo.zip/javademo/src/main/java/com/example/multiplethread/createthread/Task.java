package com.example.multiplethread.createthread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:31 2023/5/2
 * @Modified by lenovo
 **/
public class Task implements Callable<Integer> {
    private String name;
    private Integer count;

    public Task(String name, Integer count) {
        this.name = name;
        this.count = count;
    }

    @Override
    public Integer call() throws Exception {
        return count;
    }

    public static void main(String[] args) {
        //FutureTask wraps a Callable
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        List<FutureTask<Integer>> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            FutureTask<Integer> futureTask = new FutureTask<>(new Task("Task" + i, i));
            list.add(futureTask);
            //1. FutureTask implements Runnable interface, so it can work with Thread class
            new Thread(futureTask).start();
            try {
                System.out.println(futureTask.get());
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
            //2. FutureTask works with Executor
            executorService.submit(futureTask);
        }
        int result = 0;
        try {
            for (FutureTask<Integer> integerFutureTask : list) {
                result += integerFutureTask.get();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } finally {
            executorService.shutdown();
        }
        System.out.println("result=" + result);
    }
}
