package com.example.multiplethread.quiz;

import java.util.LinkedList;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 16:06 2023/6/19
 * @Modified by lenovo
 **/
public class ProducerConsumer1 {
    public static void main(String[] args) {
        ProductBlockingQueue productQueue = new ProductBlockingQueue(2);
        for (int i = 0; i < 3; i++) {
            int id = i;
            new Thread(() -> {
                try {
                    productQueue.put(new Product(id, "product" + id));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }

        new Thread(
                () -> {
                    while (true) {
                        try {
                            productQueue.take();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        try {
                            TimeUnit.SECONDS.sleep(1);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }}).start();
    }
}

final class Product {
    private final int id;
    private final Object desc;

    public Product(int id, Object desc) {
        this.id = id;
        this.desc = desc;
    }

    public int getId() {
        return id;
    }

    public Object getDesc() {
        return desc;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", desc=" + desc +
                '}';
    }
}

class ProductQueue {
    private int capacity;
    private LinkedList<Product> list = new LinkedList<>();

    public ProductQueue(int capacity) {
        this.capacity = capacity;
    }

    public void put(Product product) {
        synchronized (list) {
            while (list.size() == capacity) {
                try {
                    System.out.println("Not allow to put because of full queue");
                    list.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            list.addLast(product);
            System.out.println("put product " + product);
            list.notifyAll();
        }
    }

    public Product take() {
        synchronized (list) {
            while (list.isEmpty()) {
                try {
                    System.out.println("nothing to take ");
                    list.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            Product product = list.removeFirst();
            System.out.println("take product " + product);
            list.notifyAll();
            return product;
        }
    }
}

class ProductBlockingQueue extends ArrayBlockingQueue<Product> {
    private int capacity;
    public ProductBlockingQueue(int capacity) {
        super(capacity);
    }

    @Override
    public void put(Product product) throws InterruptedException {
        System.out.println("put " + product);
        super.put(product);
    }

    @Override
    public Product take() throws InterruptedException {
        Product product = super.take();
        System.out.println("take " + product);
        return product;
    }
}