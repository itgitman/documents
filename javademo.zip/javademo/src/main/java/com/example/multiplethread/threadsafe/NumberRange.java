package com.example.multiplethread.threadsafe;

import com.example.multiplethread.NotThreadSafe;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * 这个类不是线程安全的，虽然类的每个状态是线程安全的，但是它们之间有不变性条件的约束。
 * 必须通过加锁机制保证这些复合操作是原子的，才能实现线程安全。
 **/
@NotThreadSafe
public class NumberRange {
    //多个变量之间的不变性条件 lower<=upper
    private final AtomicInteger lower = new AtomicInteger(0);
    private final AtomicInteger upper = new AtomicInteger(0);
    public void setLower(int i) {
        //先检查后执行（race condition），不是原子操作，不安全
        if (i > upper.get()) {
            throw new IllegalArgumentException("can't set lower to " + i + " > upper");
        }
        lower.set(i);
    }
    public void setUpper(int i) {
        //先检查后执行（race condition），不是原子操作，不安全
        if (i < lower.get()) {
            throw new IllegalArgumentException("can't set upper to " + i + " < lower");
        }
        upper.set(i);
    }
    public boolean isInRange(int i) {
        return (i >= lower.get() && i <= upper.get());
    }
}
