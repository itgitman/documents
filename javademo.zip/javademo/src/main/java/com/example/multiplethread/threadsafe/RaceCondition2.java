package com.example.multiplethread.threadsafe;

import com.example.multiplethread.NotThreadSafe;
import com.example.multiplethread.ThreadSafe;

/**
 * 线程安全的单例模式
 **/
@ThreadSafe
public class RaceCondition2 {
    private RaceCondition2 instance = null;

    private RaceCondition2() {
    }

    //使用加内置锁的同步机制修改成员变量
    public synchronized RaceCondition2 getInstance() {
        //惰性初始化
        //race condition 先检查后执行
        if(instance == null)
            instance =  new RaceCondition2();
        return instance;
    }
}
