package com.example.multiplethread.threadsafe;

import com.example.multiplethread.ThreadSafe;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 13:30 2023/3/14
 * @Modified by lenovo
 **/
@ThreadSafe
public class Counting {
    //将类的状态委托给线程安全的类
    private final AtomicInteger count = new AtomicInteger(0);
    public void increment() {
        count.incrementAndGet();
    }

    public int getCount() {
        return count.get();
    }
}
