package com.example.multiplethread.quiz;

/**
 * 两个线程轮流打印1-100, 输出123456789...
 * Thread numbers flag  nextFlag(flag=!flag)
 * t1  1  3  5  odd  even
 * t2  2  4  6  even odd
 **/
public class OddEvenPrint {
    private int maxNumber = 10;
    private static int number = 1; //全局变量
    private boolean flag = true; //初始状态

    public OddEvenPrint(int maxNumber) {
        this.maxNumber = maxNumber;
    }

    public void print(boolean isEven) {
        synchronized (this) {
            while (number < maxNumber) {
                while (flag != isEven) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println(Thread.currentThread().getName() + ": " + number++);
                flag = !flag; //改变状态，让另外一个线程打印 （线程调度标志）
                notify();
            }
        }
    }

    public static void main(String[] args) {
        OddEvenPrint task = new OddEvenPrint(100);
        new Thread(() -> task.print(true)).start();
        new Thread(() -> task.print(false)).start();
    }
}
