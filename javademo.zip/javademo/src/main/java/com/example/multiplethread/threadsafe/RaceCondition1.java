package com.example.multiplethread.threadsafe;

import com.example.multiplethread.NotThreadSafe;

/**
 * 非线程安全的单例
 **/
@NotThreadSafe
public class RaceCondition1 {
    private RaceCondition1 instance = null;

    private RaceCondition1() {
    }
    public RaceCondition1 getInstance() {
        //惰性初始化
        //race condition 先检查后执行
        if(instance == null)
            instance =  new RaceCondition1();
        return instance;
    }
}
