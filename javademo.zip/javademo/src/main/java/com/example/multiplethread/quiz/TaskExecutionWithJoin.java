package com.example.multiplethread.quiz;

/**
 * 要求线程a执行完才开始线程b, 线程b执行完才开始线程C
 */

public class TaskExecutionWithJoin {
    public void print() {
        for (int i = 0; i < 10 ; i++) {
            System.out.println(Thread.currentThread().getName() + ": " + i);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        TaskExecutionWithJoin task = new TaskExecutionWithJoin();
        Thread t1 = new Thread(() -> task.print());
        Thread t2 = new Thread(() -> task.print());
        Thread t3 = new Thread(() -> task.print());
        t1.start();
        t1.join(); //wait for the t1 to die
        t2.start();
        t2.join();
        t3.start();
        t3.join();
    }
}
