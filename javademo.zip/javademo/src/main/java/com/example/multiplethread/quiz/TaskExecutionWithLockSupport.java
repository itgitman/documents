package com.example.multiplethread.quiz;

import java.util.concurrent.locks.LockSupport;

/**
 * 要求线程a执行完才开始线程b, 线程b执行完才开始线程C
 */

public class TaskExecutionWithLockSupport {
    static Thread t1, t2, t3;

    public void print(Thread next) {
        LockSupport.park(); //为线程调度目的禁用当前线程，除非许可可用。
        for (int i = 0; i < 10; i++) {
            System.out.println(Thread.currentThread().getName() + ": " + i);
        }
        if (next != null)
            LockSupport.unpark(next);
    }

    public static void main(String[] args) throws InterruptedException {
        TaskExecutionWithLockSupport task = new TaskExecutionWithLockSupport();
        t1 = new Thread(() -> task.print(t2));
        t2 = new Thread(() -> task.print(t3));
        t3 = new Thread(() -> task.print(null));
        t1.start();
        t2.start();
        t3.start();
        LockSupport.unpark(t1);
    }
}
