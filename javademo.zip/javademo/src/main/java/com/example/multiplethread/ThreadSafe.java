package com.example.multiplethread;

/**
 * Indicates a class is thread-safe
 **/
public @interface ThreadSafe {
}
