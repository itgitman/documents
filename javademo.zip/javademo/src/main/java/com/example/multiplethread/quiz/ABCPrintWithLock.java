package com.example.multiplethread.quiz;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 使用三个线程交替打印A，B，C； 打印顺序是ABCABCABC...
 * Thread,  String, wait flag, next flag
 * t1  A, 0, 1
 * t2  B, 1, 2
 * t3  c, 2, 0
 */
public class ABCPrintWithLock extends ReentrantLock {
    private int number;

    public ABCPrintWithLock(int number) {
        this.number = number;
    }

    public void print(String str, Condition currCondition, Condition nextCondition) {
        for (int i = 0; i < number ; i++) {
            lock();
            try {
                try {
                    currCondition.await();
                    System.out.print(str);
                    nextCondition.signalAll();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } finally {
                unlock();
            }
        }
    }

    public static void main(String[] args) {
        ABCPrintWithLock task = new ABCPrintWithLock(10);
        Condition a = task.newCondition();
        Condition b = task.newCondition();
        Condition c = task.newCondition();
        new Thread(()->task.print("a", a, b)).start();
        new Thread(()->task.print("b", b, c)).start();
        new Thread(()->task.print("c", c, a)).start();
        task.lock();
        try {
            a.signal();
        } finally {
            task.unlock();
        }
    }
}
