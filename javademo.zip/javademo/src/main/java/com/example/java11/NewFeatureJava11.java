package com.example.java11;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Java Language Updates
 * 1. Local Variable Type Inference - var: 本地变量推导var类型变量 - java 9, 10, 11
 * 2. List and Set API improvement, added of(...) method to create immutable collection - java 9
 * 3. List and Set API improvement, added copyOf() method returning immutable list- java 10
 * 4. String API updates: add more methods isBlank, repeat, lines, strip, stripTailing, stripLeading - java 11
 * 5. HttpClient class - Java 11
 * 6. more concise try-with-resources statement - Java 9
 * 7. Optional API improvement - Java 9, 10, 11
 * 8. Stream API improvement - Java 9
 * 9. Support for private interface methods - Java 9
 * 10. JShell - Java 9
 * 11. module - Java 9
 **/
public class NewFeatureJava11 {
    public static void main(String[] args) {
        /**
         * Local Variable Type Inference
         */
        // You can declare local variables with non-null initializers with the var identifier,
        // which can help you write code that’s easier to read.
        // the type of the variable is inferred from context
        var numbers = List.of(1,2,3,4,5);
        Optional<Integer> result = numbers.stream().reduce((var e, var e1) -> e + e1);
        System.out.println(result.orElse(0));

        //工厂方法of返回不可变的集合
        List<String> list1 = List.of("a1", "a2", "a3", "a4", "a5");
//        list1.add("cc");
        list1.stream().forEach(System.out::println);
        System.out.println("===========");
        list1.stream().takeWhile( x -> x.compareTo("a3") < 0).forEach(System.out::println);
        System.out.println("===========");
        list1.stream().dropWhile( x -> x.compareTo("a3") < 0).forEach(System.out::println);
        System.out.println("===========");
        System.out.println(Stream.of("aa", "bb", null).count());
        System.out.println(Stream.of().count());
        //Optional获取 stream
        List<String> list = new ArrayList<>();
        list.add("Tom");
        list.add("Jerry");
        list.add("Tim");
        Optional<List<String>> optional = Optional.ofNullable(list);
        Stream<List<String>> stream = optional.stream();
        stream.flatMap(x -> x.stream()).forEach(System.out::println);

        ClassLoader classLoader = NewFeatureJava11.class.getClassLoader();
//        System.out.println(classLoader);
//        System.out.println(ArrayList.class.getClassLoader());
//        InputStream in = classLoader.getResourceAsStream("hello.txt");
//        System.out.println(in);
        try(InputStream in = classLoader.getResourceAsStream("hello.txt");
            OutputStream out = new FileOutputStream("hello1.txt")) {
            in.transferTo(out);
        } catch(IOException e) {
            e.getStackTrace();
        }
    }

    public void hello() {
        var a =  100;
    }
}
