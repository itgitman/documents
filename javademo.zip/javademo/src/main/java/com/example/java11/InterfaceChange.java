package com.example.java11;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 7:26 2023/3/19
 * @Modified by lenovo
 **/
public interface InterfaceChange {
    default void methodA() {
        init();
    }
    private void init() {
        System.out.println("init");
    }
}
