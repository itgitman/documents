package com.example.modeling1.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:25 2023/2/21
 * @Modified by lenovo
 **/
public interface Switchable {
    void turnOn();
    void turnOff();
}
