package com.example.modeling1;

/**
 * 两个对象协作，如何解耦？
 * 面向接口编程
 * 另外的例子：
 * 地铁进站闸机 与 闸机控制器
 * 阅读器 与 文本转换器
 */
public class Button {
    public void poll(Lamp lamp) {
        //lamp.turnOn();
        //lamp.turnOff();
    }
}
