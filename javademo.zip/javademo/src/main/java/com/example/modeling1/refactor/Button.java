package com.example.modeling1.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:24 2023/2/21
 * @Modified by lenovo
 **/
public class Button {
    public void poll(Switchable switchable) {
        //lamp.turnOn();
        //lamp.turnOff();
    }

    public static void main(String[] args) {
        Lamp lamp = new Lamp();

    }
}
