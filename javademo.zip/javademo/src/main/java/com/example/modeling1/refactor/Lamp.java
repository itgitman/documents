package com.example.modeling1.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 14:54 2023/2/21
 * @Modified by lenovo
 **/
public class Lamp implements Switchable {
    public void turnOn() {
        //TODO
    }

    public void turnOff() {
        //TODO
    }
}
