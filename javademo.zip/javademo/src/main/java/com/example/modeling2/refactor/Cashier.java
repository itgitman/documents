package com.example.modeling2.refactor;

import com.example.modeling2.refactor.Customer;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:18 2023/2/21
 * @Modified by lenovo
 **/
public class Cashier {
    public void charge(Customer customer, double payment) {
        //Cashier不应该知道Wallet的存在，更不能知道Wallet的信息
        customer.pay(payment);
    }

}
