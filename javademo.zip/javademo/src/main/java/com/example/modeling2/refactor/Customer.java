package com.example.modeling2.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:18 2023/2/21
 * @Modified by lenovo
 **/
public class Customer {
    private String name;
    private Wallet wallet;
    public Customer(String name, Wallet wallet) {
        this.name = name;
        this.wallet = wallet;
    }
    public String getName() { return name; }
    public void pay(double payment) { //付钱是Customer对象的职责

//        if(wallet.getTotalMoney() > payment)
        if (wallet.isEnough(payment))
            wallet.subtractMoney(payment);
        else
            throw new IllegalStateException();
    }

}
