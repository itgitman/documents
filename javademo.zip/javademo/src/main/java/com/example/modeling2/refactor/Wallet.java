package com.example.modeling2.refactor;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 15:18 2023/2/21
 * @Modified by lenovo
 **/
public class Wallet {
    private double value;

    public Wallet(double value) {
        this.value = value;
    }

    //根据业务需要是否提供total money
    public double getTotalMoney() {
     return value;
    }

    //检查是否钱足够是Wallet对象的职责, Tell, Don't Ask
    public Boolean isEnough(double payment) {
        return value >= payment;
    }

    public void addMoney(double deposit) {
        value += deposit;
    }

    public void subtractMoney(double debit) {
        value -= debit;
    }
}
