package com.example.modeling2;

public class Wallet {
    private double value;

    public Wallet(double value) {
        this.value = value;
    }

    public double getTotalMoney() {
        return value;
    }

    public void addMoney(double deposit) {
        value += deposit;
    }

    public void subtractMoney(double debit) {
        value -= debit;
    }
}
