package com.example.modeling2;

public class Customer {
    private String name;
    private Wallet wallet; // Customer has a Wallet
    public Customer(String name, Wallet wallet) {
        this.name = name;
        this.wallet = wallet;
    }
    public String getName() {
        return name;
    }
    public Wallet getWallet() {
        return wallet;
    }
}