package com.example.modeling2;

public class Cashier {
  public void charge(Customer customer, double payment) {
    //按照迪米特法则，Cashier不应该知道Wallet,也就是收银员不应该知道客户的钱包有多少钱。 
    Wallet wallet = customer.getWallet();
    if(wallet.getTotalMoney() >= payment) {
      wallet.subtractMoney(payment);
    } else {
      throw new IllegalStateException();
    }
  }
}
