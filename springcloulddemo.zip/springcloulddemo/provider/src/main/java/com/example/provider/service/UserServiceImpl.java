package com.example.provider.service;

import com.example.provider.dao.UserDao;
import com.example.provider.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 11:00 2022/12/17
 * @Modified by lenovo
 **/
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;
    @Override
    public User findById(Long id) {
        return userDao.findById(id);
    }
}
