package com.example.provider.model;

import lombok.Data;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 11:00 2022/12/17
 * @Modified by lenovo
 **/
@Data
public class User {
    private Long id;
    private String username;
    private String password;
    private Boolean enabled;//true=1, false=0
    private Boolean locked;//true=1, false=0
}
