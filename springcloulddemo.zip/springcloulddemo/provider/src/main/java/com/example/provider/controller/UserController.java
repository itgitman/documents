package com.example.provider.controller;

import com.example.provider.config.ConfigInfoProperties;
import com.example.provider.model.User;
import com.example.provider.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:59 2022/12/17
 * @Modified by lenovo
 **/
@RestController
public class UserController {
    @Autowired
    private ConfigInfoProperties config;
    @Autowired
    private UserService userService;
    @GetMapping("/user/{id}")
    public User findById(@PathVariable("id") Long  id) {
        return userService.findById(id);
    }
    @GetMapping("/config")
    public String getConfig() {
        return config.getConfig() + ", hello!";
    }
}
