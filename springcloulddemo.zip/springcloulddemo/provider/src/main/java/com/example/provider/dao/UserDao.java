package com.example.provider.dao;

import com.example.provider.model.User;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 11:00 2022/12/17
 * @Modified by lenovo
 **/

public interface UserDao {

    User findById(Long id);
}
