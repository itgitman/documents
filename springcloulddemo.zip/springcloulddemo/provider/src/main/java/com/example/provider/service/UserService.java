package com.example.provider.service;


import com.example.provider.model.User;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 10:59 2022/12/17
 * @Modified by lenovo
 **/
public interface UserService {
    User findById(Long id);
}
