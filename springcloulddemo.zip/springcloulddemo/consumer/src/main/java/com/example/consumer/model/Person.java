package com.example.consumer.model;

import lombok.Data;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:57 2022/12/18
 * @Modified by lenovo
 **/
@Data
public class Person {
    private Long id;
    private String username;
    private String password;

    public Person() {
    }

    public Person(Long id, String username, String password) {
        this.id = id;
        this.username = username;
        this.password = password;
    }
}
