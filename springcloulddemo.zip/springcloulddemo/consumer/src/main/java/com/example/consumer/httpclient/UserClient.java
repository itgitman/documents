package com.example.consumer.httpclient;

import com.example.consumer.model.Person;
import com.example.consumer.service.UserServiceFallback;
import feign.Headers;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:46 2022/12/18
 * @Modified by lenovo
 **/
@Headers("")
@FeignClient(name="hello", url = "http://localhost:8081/", fallback=UserServiceFallback.class)
public interface UserClient {
    @GetMapping("/user/{id}")
    public Person getPerson(@PathVariable("id") Long id);
}
