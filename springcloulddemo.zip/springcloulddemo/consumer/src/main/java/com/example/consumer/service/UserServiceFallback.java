package com.example.consumer.service;

import com.example.consumer.model.Person;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 11:01 2022/12/18
 * @Modified by lenovo
 **/
@Component
public class UserServiceFallback {
    public Person getPerson() {
        return new Person(0L, "Sunny Wu", "123456");
    }
}
