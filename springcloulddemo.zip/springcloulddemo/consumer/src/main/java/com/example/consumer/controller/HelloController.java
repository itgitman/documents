package com.example.consumer.controller;

import com.example.consumer.httpclient.UserClient;
import com.example.consumer.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author lenovo
 * @Description:
 * @Date created at 9:46 2022/12/18
 * @Modified by lenovo
 **/
@RestController
public class HelloController {
    @Autowired
    private UserClient userClient;
    @GetMapping("/person/{id}")
    public Person getPerson(@PathVariable("id") Long id) {
        return userClient.getPerson(id);
    }
}
